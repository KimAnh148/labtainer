#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [ "${DNS_WILDCARD:-0}" = "1" ]; then set -- --wildcard "$@"; fi
exec sudo python3 ./lab_runtime.py start_dns01 "$@"
