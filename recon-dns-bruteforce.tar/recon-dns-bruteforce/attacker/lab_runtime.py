#!/usr/bin/env python3
"""Runtime cho bai lab recon-dns-bruteforce (dns01 / attacker / splunk)."""
import argparse, json, os, re, shutil, socket, ssl, subprocess, sys, time
import urllib.parse, urllib.request
from pathlib import Path

DNS, ATK, SPL = '172.21.0.10', '172.21.0.20', '172.21.0.30'
ZONE = 'corp.local'
SPLUNK_USER, SPLUNK_PW, SPLUNK_HOME = 'analyst', 'Splunk!Lab2026', Path('/opt/splunk')
QUERY_LOG, SHIP_PORT = Path('/var/log/named/query.log'), 5514
DONE = Path('/var/lib/bind-lab/.provisioned')
NAMED_CONF_LOCAL = Path('/etc/bind/named.conf.local')
ZONE_FILE = Path('/etc/bind/zones/db.corp.local')
WILDCARD_IP = '172.21.0.99'
# 6 subdomain THAT (ton tai) theo dung kich ban; con lai trong wordlist deu la gia.
REAL_SUBS = {'vpn': 51, 'mail': 52, 'dev': 53, 'git': 54, 'www': 55, 'admin': 56}

ZONE_HEADER = '''$TTL 3600
@       IN      SOA     dns01.corp.local. admin.corp.local. (
                        2026110400 ; serial
                        3600       ; refresh
                        900        ; retry
                        604800     ; expire
                        3600 )     ; minimum
        IN      NS      dns01.corp.local.
dns01   IN      A       %s
''' % DNS

NAMED_LOCAL_TEXT = '''zone "corp.local" {
    type master;
    file "/etc/bind/zones/db.corp.local";
    allow-transfer { none; };
};

logging {
    channel query_log_file {
        file "/var/log/named/query.log" versions 3 size 5m;
        severity info;
        print-time yes;
    };
    category queries { query_log_file; };
};
'''


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, **kw)


def out(args, **kw):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, **kw)


def root():
    require(os.geteuid() == 0, 'Hay chay bang script wrapper (can sudo).')


def listening(port, proto='t'):
    flag = '-ltn' if proto == 't' else '-lun'
    return bool(out(['ss', '-H', flag, 'sport', '=', ':' + str(port)]).strip())


def wait_for(cond, seconds, msg):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return
        time.sleep(1)
    raise RuntimeError(msg)


def check_disk(need_mb):
    free = shutil.disk_usage('/').free // 2**20
    require(free >= need_mb, 'O dia con trong %d MB (can >= %d MB). Giai phong dia tren may Ubuntu '
            '(docker system prune) roi stoplab va chay lai.' % (free, need_mb))


def hosts_add(ip, names):
    p = Path('/etc/hosts')
    if names.split()[0] not in p.read_text():
        with p.open('a') as f:
            f.write('\n' + ip + ' ' + names + '\n')


def named_running():
    # KHONG dung pgrep ten tien trinh: mot zombie 'named <defunct>' tu lan chay truoc van
    # khop pgrep -x named, khien code tuong nham la dang chay va bo qua khoi dong lai that.
    return listening(53)


def build_zone_text(wildcard):
    t = ZONE_HEADER + ''.join('%-6s IN      A       172.21.0.%d\n' % (h, o) for h, o in REAL_SUBS.items())
    if wildcard:
        t += '*       IN      A       %s\n' % WILDCARD_IP
    return t


WILDCARD_STATE = Path('/var/lib/bind-lab/wildcard')


def zone_loaded():
    # named DANG CHAY co thuc su biet zone corp.local khong (khac voi file tren dia hop le).
    return subprocess.run(['rndc', 'zonestatus', ZONE], capture_output=True).returncode == 0


def want_wildcard(args):
    # Bat/tat wildcard DNS (mac dinh: TAT). Hai cach, deu tuong duong:
    #   ./start_dns01.sh --wildcard            (hoac --no-wildcard)
    #   DNS_WILDCARD=1 ./start_dns01.sh        (wrapper doi bien moi truong thanh --wildcard,
    #                                           vi sudo xoa sach bien moi truong cua nguoi goi)
    # QUAN TRONG: khi wildcard BAT, moi ten khong ton tai deu tra ve NOERROR (qua IP wildcard)
    # thay vi NXDOMAIN, nen cau SPL o Buoc 5 (tim "NXDOMAIN") se KHONG CO ket qua va Buoc 6
    # (check_detection) se khong dat duoc. Mac dinh TAT de dam bao toan bo bai (den het Buoc 6)
    # co the hoan thanh; bat wildcard chi nen dung de minh hoa rieng Buoc 1-3.
    if '--wildcard' in args:
        return True
    if '--no-wildcard' in args:
        return False
    return os.environ.get('DNS_WILDCARD', '0') == '1'


def start_dns01(args=()):
    root()
    check_disk(200)
    require(Path('/usr/sbin/named').exists(), 'Khong tim thay named (goi bind9). Kiem tra lai image.')
    hosts_add(DNS, 'dns01.corp.local dns01')
    wildcard = want_wildcard(args)
    recorded = WILDCARD_STATE.read_text().strip() if WILDCARD_STATE.exists() else None
    # Ghi lai zone khi chay lan dau HOAC khi doi che do wildcard so voi lan truoc.
    fresh = (not DONE.exists()) or recorded != ('1' if wildcard else '0')
    if fresh:
        Path('/var/lib/bind-lab').mkdir(parents=True, exist_ok=True)
        Path('/etc/bind/zones').mkdir(parents=True, exist_ok=True)
        Path('/var/log/named').mkdir(parents=True, exist_ok=True)
        ZONE_FILE.write_text(build_zone_text(wildcard))
        r = subprocess.run(['named-checkzone', ZONE, str(ZONE_FILE)], text=True, capture_output=True)
        require(r.returncode == 0, 'Zone file loi:\n' + r.stdout + r.stderr)
        NAMED_CONF_LOCAL.write_text(NAMED_LOCAL_TEXT)
        r = subprocess.run(['named-checkconf'], text=True, capture_output=True)
        require(r.returncode == 0, 'named.conf loi:\n' + r.stdout + r.stderr)
        run(['chown', '-R', 'bind:bind', '/etc/bind/zones', '/var/log/named'])
        WILDCARD_STATE.write_text('1' if wildcard else '0')
        DONE.write_text('ok')
    if named_running() and (fresh or not zone_loaded()):
        # named da chay san tu luc container khoi dong (truoc khi zone/cau hinh duoc ghi) nen
        # khong biet zone corp.local -> SERVFAIL. Dung han roi khoi dong lai de nap dung cau hinh.
        subprocess.run(['rndc', 'stop'], capture_output=True)
        subprocess.run(['pkill', '-x', 'named'], capture_output=True)
        wait_for(lambda: not listening(53), 20, 'named cu khong thoat duoc.')
    if not named_running():
        # QUAN TRONG: chay named o che do daemon THAT (khong co '-g'), de no tu fork/detach.
        run(['named', '-u', 'bind', '-c', '/etc/bind/named.conf'])
    try:
        wait_for(lambda: listening(53) and listening(53, 'u'), 60, '')
    except RuntimeError:
        errs = subprocess.run("tail -20 /var/log/syslog 2>/dev/null", shell=True, text=True,
                              capture_output=True).stdout
        procs = subprocess.run(['pgrep', '-a', 'named'], text=True, capture_output=True).stdout
        raise RuntimeError('named chua lang nghe cong 53.\nTien trinh:\n%s\nLog:\n%s' % (procs, errs))
    try:
        wait_for(zone_loaded, 30, '')
    except RuntimeError:
        raise RuntimeError('named dang chay nhung chua nap zone %s (rndc zonestatus loi).' % ZONE)
    if shutil.which('dig'):
        probe = subprocess.run(['dig', '@127.0.0.1', 'vpn.' + ZONE, 'A', '+short', '+norecurse'],
                               text=True, capture_output=True).stdout
        require('172.21.0.%d' % REAL_SUBS['vpn'] in probe,
                'Zone khong tra ve vpn.corp.local. Ket qua dig: %r' % probe)
    stop_shipper()
    QUERY_LOG.touch()
    run(['chown', 'bind:bind', str(QUERY_LOG)])
    log = open('/var/log/lab-shipper.log', 'a')
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'ship'],
                            start_new_session=True, stdout=log, stderr=log)
    Path('/run/lab-shipper.pid').write_text(str(proc.pid))
    print('Zone corp.local san sang tren dns01 (UDP/TCP 53). Wildcard DNS: %s.' %
          ('BAT (' + WILDCARD_IP + ')' if wildcard else 'TAT'))
    print('Shipper log -> Splunk %s:%d' % (SPL, SHIP_PORT))
    print('DNS01_READY')


def stop_shipper():
    p = Path('/run/lab-shipper.pid')
    if p.exists():
        try:
            os.kill(int(p.read_text()), 15)
        except (OSError, ValueError):
            pass
        p.unlink(missing_ok=True)


# ---- shipper: doc BIND9 query log, TU TRA CUU LAI tung truy van de biet ma tra loi -----
# QUAN TRONG: log "category queries" cua BIND chi ghi CAU HOI, khong bao gio ghi MA TRA LOI
# (da xac minh qua nhieu nguon, bao gom phat bieu cua chinh nha phat trien BIND: NXDOMAIN
# khong duoc coi la loi nen khong duoc ghi vao category 'query-errors'). Vi vay shipper tu
# tra cuu lai (qua dnspython) de biet NXDOMAIN hay NOERROR, roi moi chuan hoa gui sang Splunk.
MONTHS = {m: i + 1 for i, m in enumerate(
    ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])}
QLINE = re.compile(
    r'^(\d\d)-(\w{3})-(\d{4}) (\d\d:\d\d:\d\d)\.\d+ client(?:\s*@\S+)? '
    r'([0-9a-fA-F:.]+)#\d+ \(([^)]+)\): query: (\S+) IN (\S+)')


_RESOLVER = None
# Truy van tra cuu lai cua CHINH shipper den named tu 127.0.0.1, nen cung duoc named ghi vao
# query.log. Phai bo qua moi dong tu loopback, neu khong se tao vong lap vo han: moi dong log ->
# shipper tra cuu lai -> sinh dong log moi tu 127.0.0.1 -> shipper lai tra cuu... (tran Splunk
# bang su kien gia, va client_ip=127.0.0.1 tu no da vuot nguong "count > 50" cua cau SPL).
LOOPBACK = ('127.0.0.1', '::1')


def resolve_status(qname, qtype):
    global _RESOLVER
    import dns.resolver
    import dns.rdatatype
    if _RESOLVER is None:
        _RESOLVER = dns.resolver.Resolver(configure=False)
        _RESOLVER.nameservers = ['127.0.0.1']
        _RESOLVER.timeout, _RESOLVER.lifetime = 2, 2
    ask = getattr(_RESOLVER, 'resolve', None) or _RESOLVER.query   # dnspython 2.x / 1.16 (focal)
    try:
        rtype = dns.rdatatype.from_text(qtype)
    except Exception:
        rtype = dns.rdatatype.A
    try:
        ask(qname, rtype)
        return 'NOERROR'
    except dns.resolver.NXDOMAIN:
        return 'NXDOMAIN'
    except dns.resolver.NoAnswer:      # ten co ton tai nhung khong co loai ban ghi nay
        return 'NOERROR'
    except Exception:
        return 'UNKNOWN'


def normalize(line):
    m = QLINE.match(line)
    if not m:
        return None
    day, mon, year, t, client_ip, qname_paren, qname, qtype = m.groups()
    if client_ip in LOOPBACK:
        return None
    mnum = MONTHS.get(mon)
    if not mnum:
        return None
    ts = '%s-%02d-%s %s' % (year, mnum, day, t)
    status = resolve_status(qname, qtype)
    q = lambda s: s.replace('"', "'")
    return ('%s op=dns_query client_ip=%s qname=%s qtype=%s status=%s query="%s IN %s %s"'
            % (ts, client_ip, q(qname), qtype, status, q(qname), qtype, status))


def ship():
    root()
    from collections import deque
    pend, buf = deque(), b''
    off = QUERY_LOG.stat().st_size if QUERY_LOG.exists() else 0
    sock = None
    while True:
        size = QUERY_LOG.stat().st_size if QUERY_LOG.exists() else 0
        if size < off:
            off, buf = 0, b''
        if size > off:
            with QUERY_LOG.open('rb') as f:
                f.seek(off)
                data = f.read(size - off)
            off += len(data)
            buf += data
            *lines, buf = buf.split(b'\n')
            for raw in lines:
                ev = normalize(raw.decode(errors='replace'))
                if ev:
                    pend.append(ev)
        if pend:
            try:
                if sock is None:
                    sock = socket.create_connection((SPL, SHIP_PORT), timeout=5)
                while pend:
                    sock.sendall((pend[0] + '\n').encode())
                    print('shipped:', pend.popleft(), flush=True)
            except OSError:
                if sock:
                    sock.close()
                sock = None
                time.sleep(3)
        time.sleep(.2)


# ------------------------------------------------------------ attacker
def gobuster_dns(args):
    # gobuster co CU PHAP DONG LENH KHAC NHAU rat nhieu giua cac ban:
    #   v2 (Ubuntu 20.04, "gobuster -m dns -u DOMAIN -w WORDLIST -fw -i -o OUT"): khong co
    #      subcommand, dung "-u" cho domain, "-fw" de ep xu ly wildcard.
    #   v3 (Ubuntu 22.04+, "gobuster dns -d DOMAIN -w WORDLIST --wildcard -i -o OUT"): co
    #      subcommand "dns", dung "-d" cho domain, "--wildcard" de ep xu ly wildcard.
    # Wrapper nay nhan tham so kieu v3 (-d domain -w wordlist [-i] [--wildcard] -o out) va tu
    # dich sang dung cu phap cua ban gobuster that su co trong image, de script hoat dong deu
    # tren ca hai moi truong (image build tu Ubuntu 20.04 hoac 22.04+ deu co the xay ra).
    ap = argparse.ArgumentParser(prog='gobuster-dns')
    ap.add_argument('-d', '--domain', required=True)
    ap.add_argument('-w', '--wordlist', required=True)
    ap.add_argument('-o', '--output', required=True)
    ap.add_argument('-i', action='store_true')
    ap.add_argument('--wildcard', action='store_true')
    a = ap.parse_args(args)
    # gobuster v2 khong co lenh con "version" dung nghia (chi bao loi thieu -w/-u), nen
    # phai phan biet qua --help: ban v3 (cobra-style) liet ke "Available Commands:", ban v2
    # (flag package kieu cu) thi khong.
    help_out = subprocess.run(['gobuster', '--help'], capture_output=True, text=True)
    help_text = help_out.stdout + help_out.stderr
    is_v2 = 'Available Commands' not in help_text
    if is_v2:
        cmd = ['gobuster', '-m', 'dns', '-u', a.domain, '-w', a.wordlist, '-o', a.output]
        if a.i:
            cmd.append('-i')
        if a.wildcard:
            cmd.append('-fw')
    else:
        cmd = ['gobuster', 'dns', '-d', a.domain, '-w', a.wordlist, '-o', a.output]
        if a.i:
            cmd.append('-i')
        if a.wildcard:
            cmd.append('--wildcard')
    print('(gobuster-dns) dang goi:', ' '.join(cmd))
    r = subprocess.run(cmd)
    sys.exit(r.returncode)


def setup_attacker():
    root()
    hosts_add(DNS, 'dns01.corp.local dns01')
    require(shutil.which('gobuster'), 'Khong co gobuster tren attacker. Kiem tra lai image.')
    s = socket.socket(); s.settimeout(5)
    require(s.connect_ex((DNS, 53)) == 0, 'Khong ket noi duoc dns01:53 (TCP). Da chay ./start_dns01.sh chua?')
    s.close()
    # QUAN TRONG: lenh goc cua bai ("gobuster dns -d corp.local -w ... -o ...") KHONG co co
    # chi dinh may chu DNS (khong co -r/--resolver). gobuster (ca v2 lan v3) khi do se dung
    # resolver mac dinh cua he thong (/etc/resolv.conf), KHONG dung /etc/hosts. Neu khong tro
    # resolv.conf ve dns01, gobuster se khong tra loi duoc gi ca du dns01 van chay binh thuong.
    rc = Path('/etc/resolv.conf')
    rc.write_text('nameserver %s\n' % DNS)
    print('Da them dns01.corp.local vao /etc/hosts va tro /etc/resolv.conf ve dns01 (%s).' % DNS)
    print('DNS (53) tren dns01 da san sang.')
    print('ATTACKER_READY')


# -------------------------------------------------------------- splunk
CONF = {
    'indexes.conf': '[dns_recon]\nhomePath = $SPLUNK_DB/dns_recon/db\ncoldPath = $SPLUNK_DB/dns_recon/colddb\n'
                    'thawedPath = $SPLUNK_DB/dns_recon/thaweddb\n',
    'inputs.conf': '[tcp://%d]\nindex = dns_recon\nsourcetype = bind:querylog\nconnection_host = none\n' % SHIP_PORT,
    'props.conf': '[bind:querylog]\nSHOULD_LINEMERGE = false\nKV_MODE = auto\nTIME_PREFIX = ^\n'
                  'TIME_FORMAT = %Y-%m-%d %H:%M:%S\nMAX_TIMESTAMP_LOOKAHEAD = 20\n',
    'user-seed.conf': '[user_info]\nUSERNAME = %s\nPASSWORD = %s\n' % (SPLUNK_USER, SPLUNK_PW),
}


def start_splunk():
    root()
    check_disk(1500)
    require(SPLUNK_HOME.exists(), 'Khong thay Splunk tai /opt/splunk (kiem tra buoc build image).')
    local = SPLUNK_HOME / 'etc/system/local'
    local.mkdir(parents=True, exist_ok=True)
    for name, text in CONF.items():
        if name == 'user-seed.conf' and (SPLUNK_HOME / 'etc/passwd').exists():
            continue
        (local / name).write_text(text)
    run(['chown', '-R', 'splunk:splunk', str(SPLUNK_HOME)])
    var = SPLUNK_HOME / 'var'
    var.mkdir(exist_ok=True)
    fstype = out(['stat', '-f', '-c', '%T', str(var)]).strip()
    print('Loai he tap tin cua /opt/splunk/var:', fstype)
    if fstype.startswith(('overlay', 'tmpfs')) and not listening(8089):
        print('CANH BAO: Splunk co the tu choi luu index tren ' + fstype + ' ("unusable filesystem").\n'
              'Image can khai bao VOLUME /opt/splunk/var (dung install.py moi + rebuild).')
    probe = subprocess.run(['sudo', '-u', 'splunk', 'sh', '-c',
                            'mkdir -p /opt/splunk/var/log && touch /opt/splunk/var/log/.w'],
                           text=True, capture_output=True)
    if probe.returncode:
        raise RuntimeError('User splunk khong ghi duoc /opt/splunk/var/log:\n' + probe.stderr)
    run(['sudo', '-u', 'splunk', 'sh', '-c', 'ulimit -f unlimited 2>/dev/null; exec ' + str(SPLUNK_HOME / 'bin/splunk') +
         ' start --accept-license --answer-yes --no-prompt'], stdout=subprocess.DEVNULL)
    wait_for(lambda: listening(8000) and listening(SHIP_PORT) and listening(8089), 180,
             'Splunk chua san sang (8000/8089/%d).' % SHIP_PORT)
    print('Splunk Web: http://%s:8000  (tai khoan %s / %s)' % (SPL, SPLUNK_USER, SPLUNK_PW))
    print('SPLUNK_READY')


def spl(query, host='127.0.0.1'):
    ctx = ssl._create_unverified_context()
    pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pw.add_password(None, 'https://%s:8089' % host, SPLUNK_USER, SPLUNK_PW)
    op = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), urllib.request.HTTPBasicAuthHandler(pw))
    body = urllib.parse.urlencode({'search': 'search ' + query, 'output_mode': 'json',
                                   'earliest_time': '-24h'}).encode()
    rows = []
    with op.open('https://%s:8089/services/search/jobs/export' % host, body, timeout=60) as r:
        for line in r:
            if line.strip():
                res = json.loads(line).get('result')
                if res:
                    rows.append(res)
    return rows


def check_detection(args):
    # Chay tren container attacker, goi Splunk REST API qua mang (172.21.0.30:8089).
    # Ho tro ca hai cach goi (xem HUONG_DAN.txt):
    #   ./check_detection.sh "<cau SPL mot dong>"
    #   ./check_detection.sh @duong_dan_file
    require(len(args) == 1, 'Dung: check_detection.sh "<cau SPL>"  hoac  check_detection.sh @file.txt')
    query = Path(args[0][1:]).read_text().strip() if args[0].startswith('@') else args[0].strip()
    require(query, 'Cau SPL rong.')
    rows, n = [], 0
    for _ in range(12):
        rows = spl(query, host=SPL)
        n = sum(int(r.get('count', 0)) for r in rows) if rows and 'count' in (rows[0] if rows else {}) else len(rows)
        if n > 0:
            break
        time.sleep(5)
    require(n > 0, 'Splunk chua tra ve su kien nao cho truy van nay. Chay du Buoc 2 roi thu lai.')
    for r in rows:
        print(r)
    print('DETECTION_CONFIRMED: %d events' % n)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('action')
    p.add_argument('rest', nargs=argparse.REMAINDER)
    a = p.parse_args()
    acts = {'start_dns01': start_dns01, 'ship': ship, 'setup_attacker': setup_attacker,
            'start_splunk': start_splunk}
    if a.action == 'start_dns01':
        start_dns01(a.rest)
    elif a.action in acts:
        acts[a.action]()
    elif a.action == 'gobuster_dns':
        gobuster_dns(a.rest)
    elif a.action == 'check_detection':
        check_detection(a.rest)
    else:
        raise RuntimeError('Hanh dong khong hop le: ' + a.action)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print('FAILED: ' + str(exc), file=sys.stderr); sys.exit(1)
