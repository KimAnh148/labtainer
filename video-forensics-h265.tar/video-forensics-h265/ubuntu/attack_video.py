import subprocess

print("[+] Recompressing...")

subprocess.run([
    "ffmpeg",
    "-y",
    "-i", "watermarked.mp4",
    "-c:v", "libx264",
    "-crf", "35",
    "tmp1.mp4"
])

print("[+] Applying blur...")

subprocess.run([
    "ffmpeg",
    "-y",
    "-i", "tmp1.mp4",
    "-vf", "boxblur=5:1",
    "tmp2.mp4"
])

print("[+] Cropping...")

subprocess.run([
    "ffmpeg",
    "-y",
    "-i", "tmp2.mp4",
    "-vf", "crop=iw-40:ih-40:20:20",
    "-map_metadata", "-1",
    "video_leaked_corrupted.mp4"
])

print("[+] Leak video generated")
