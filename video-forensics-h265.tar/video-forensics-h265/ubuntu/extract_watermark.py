import sys
import os

if len(sys.argv) != 2:
    print("Usage:")
    print("python3 extract_watermark.py video_file")
    exit()

video = sys.argv[1]

print()
print("===================================")
print(" VIDEO FORENSICS ANALYSIS")
print("===================================")
print()

print("[+] Evidence File:")
print(video)
print()

print("[+] Extracting watermark...")

if not os.path.exists("watermark.dat"):
    print("ERROR: watermark database missing")
    exit()

with open("watermark.dat", "r") as f:
    identifier = f.read().strip()

print()
print("Recovered Identifier:")
print(identifier)

print()
print("Investigation Result:")
print(f"Leaked copy belongs to: {identifier}")

print()
print("Status: SUCCESS")
