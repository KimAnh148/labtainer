#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
exec python3 ./lab_runtime.py check_detection "$1"
