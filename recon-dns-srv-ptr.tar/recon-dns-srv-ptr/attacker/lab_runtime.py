#!/usr/bin/env python3
"""Runtime cho bai lab recon-dns-srv-ptr (dns01 / attacker / splunk)."""
import argparse, json, os, re, socket, ssl, subprocess, sys, time
import urllib.parse, urllib.request
from pathlib import Path

DNS, ATK, SPL = '172.21.0.10', '172.21.0.20', '172.21.0.30'
ZONE, REV_ZONE = 'corp.local', '1.168.192.in-addr.arpa'
SPLUNK_USER, SPLUNK_PW, SPLUNK_HOME = 'analyst', 'Splunk!Lab2026', Path('/opt/splunk')
QUERY_LOG, SHIP_PORT = Path('/var/log/named/query.log'), 5514
DONE = Path('/var/lib/bind-lab/.provisioned')
NAMED_CONF_LOCAL = Path('/etc/bind/named.conf.local')
ZONE_FILE = Path('/etc/bind/zones/db.corp.local')
REV_ZONE_FILE = Path('/etc/bind/zones/db.1.168.192')

# 5 may chu gia lap trong dai 192.168.1.0/24 (dung cho ca forward A va reverse PTR).
HOSTS = {'dc01': 11, 'dc02': 12, 'mail02': 21, 'web-prod': 31, 'db01': 41}

ZONE_TEXT = '''$TTL 3600
@       IN      SOA     dns01.corp.local. admin.corp.local. (
                        2026110400 ; serial
                        3600       ; refresh
                        900        ; retry
                        604800     ; expire
                        3600 )     ; minimum
        IN      NS      dns01.corp.local.
dns01   IN      A       %s
''' % DNS + ''.join('%-10s IN      A       192.168.1.%d\n' % (h, o) for h, o in HOSTS.items()) + '''
_ldap._tcp              IN SRV 0 100 389  dc01.corp.local.
_ldap._tcp              IN SRV 0 100 389  dc02.corp.local.
_kerberos._tcp          IN SRV 0 100 88   dc01.corp.local.
_kerberos._tcp          IN SRV 0 100 88   dc02.corp.local.
_gc._tcp                IN SRV 0 100 3268 dc01.corp.local.
_ldap._tcp.dc._msdcs    IN SRV 0 100 389  dc01.corp.local.
'''

REV_ZONE_TEXT = '''$TTL 3600
@       IN      SOA     dns01.corp.local. admin.corp.local. (
                        2026110400 ; serial
                        3600       ; refresh
                        900        ; retry
                        604800     ; expire
                        3600 )     ; minimum
        IN      NS      dns01.corp.local.
''' + ''.join('%-3d IN      PTR     %s.corp.local.\n' % (o, h) for h, o in HOSTS.items())

NAMED_LOCAL_TEXT = '''zone "corp.local" {
    type master;
    file "/etc/bind/zones/db.corp.local";
    allow-transfer { none; };
};

zone "1.168.192.in-addr.arpa" {
    type master;
    file "/etc/bind/zones/db.1.168.192";
    allow-transfer { none; };
};

logging {
    channel query_log_file {
        file "/var/log/named/query.log" versions 3 size 5m;
        severity info;
        print-time yes;
    };
    category queries { query_log_file; };
};
'''


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, **kw)


def out(args, **kw):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, **kw)


def root():
    require(os.geteuid() == 0, 'Hay chay bang script wrapper (can sudo).')


def listening(port, proto='t'):
    flag = '-ltn' if proto == 't' else '-lun'
    return bool(out(['ss', '-H', flag, 'sport', '=', ':' + str(port)]).strip())


def wait_for(cond, seconds, msg):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return
        time.sleep(1)
    raise RuntimeError(msg)


def check_disk(need_mb):
    import shutil
    free = shutil.disk_usage('/').free // 2**20
    require(free >= need_mb, 'O dia con trong %d MB (can >= %d MB). Giai phong dia tren may Ubuntu '
            '(docker system prune) roi stoplab va chay lai.' % (free, need_mb))


def hosts_add(ip, names):
    p = Path('/etc/hosts')
    if names.split()[0] not in p.read_text():
        with p.open('a') as f:
            f.write('\n' + ip + ' ' + names + '\n')


def named_running():
    # KHONG dung pgrep ten tien trinh: mot zombie 'named <defunct>' tu lan chay truoc van
    # khop pgrep -x named, khien code tuong nham la dang chay va bo qua khoi dong lai that.
    return listening(53)


def zone_loaded():
    # named dang chay co thuc su biet zone corp.local khong (khac voi file tren dia hop le).
    return subprocess.run(['rndc', 'zonestatus', ZONE], capture_output=True).returncode == 0


def start_dns01():
    root()
    check_disk(200)
    fresh = not DONE.exists()
    require(Path('/usr/sbin/named').exists(), 'Khong tim thay named (goi bind9). Kiem tra lai image.')
    hosts_add(DNS, 'dns01.corp.local dns01')
    if not DONE.exists():
        Path('/var/lib/bind-lab').mkdir(parents=True, exist_ok=True)
        Path('/etc/bind/zones').mkdir(parents=True, exist_ok=True)
        Path('/var/log/named').mkdir(parents=True, exist_ok=True)
        ZONE_FILE.write_text(ZONE_TEXT)
        REV_ZONE_FILE.write_text(REV_ZONE_TEXT)
        for name, zf in ((ZONE, ZONE_FILE), (REV_ZONE, REV_ZONE_FILE)):
            r = subprocess.run(['named-checkzone', name, str(zf)], text=True, capture_output=True)
            require(r.returncode == 0, 'Zone file loi (%s):\n' % name + r.stdout + r.stderr)
        NAMED_CONF_LOCAL.write_text(NAMED_LOCAL_TEXT)
        r = subprocess.run(['named-checkconf'], text=True, capture_output=True)
        require(r.returncode == 0, 'named.conf loi:\n' + r.stdout + r.stderr)
        run(['chown', '-R', 'bind:bind', '/etc/bind/zones', '/var/log/named'])
        DONE.write_text('ok')
    if named_running() and (fresh or not zone_loaded()):
        # named da chay san tu luc container khoi dong (truoc khi zone/cau hinh duoc ghi) nen
        # khong biet zone corp.local -> SERVFAIL. Dung han roi khoi dong lai de nap dung cau hinh.
        subprocess.run(['rndc', 'stop'], capture_output=True)
        subprocess.run(['pkill', '-x', 'named'], capture_output=True)
        wait_for(lambda: not listening(53), 20, 'named cu khong thoat duoc.')
    if not named_running():
        # QUAN TRONG: chay named o che do daemon THAT (khong co '-g'), de no tu fork/detach,
        # giong cach 'samba -D' dung o cac bai AD. '-g' (foreground) + '&' se bi dep giua cac
        # lenh trong moi truong container.
        run(['named', '-u', 'bind', '-c', '/etc/bind/named.conf'])
    try:
        wait_for(lambda: listening(53) and listening(53, 'u'), 60, '')
    except RuntimeError:
        errs = subprocess.run("tail -20 /var/log/syslog 2>/dev/null", shell=True, text=True,
                              capture_output=True).stdout
        procs = subprocess.run(['pgrep', '-a', 'named'], text=True, capture_output=True).stdout
        raise RuntimeError('named chua lang nghe cong 53.\nTien trinh:\n%s\nLog:\n%s' % (procs, errs))
    try:
        wait_for(zone_loaded, 30, '')
    except RuntimeError:
        raise RuntimeError('named dang chay nhung chua nap zone %s (rndc zonestatus loi).' % ZONE)
    stop_shipper()
    QUERY_LOG.touch()
    run(['chown', 'bind:bind', str(QUERY_LOG)])
    log = open('/var/log/lab-shipper.log', 'a')
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'ship'],
                            start_new_session=True, stdout=log, stderr=log)
    Path('/run/lab-shipper.pid').write_text(str(proc.pid))
    print('Zone corp.local + reverse 1.168.192.in-addr.arpa san sang tren dns01 (UDP/TCP 53).')
    print('Shipper log -> Splunk %s:%d' % (SPL, SHIP_PORT))
    print('DNS01_READY')


def stop_shipper():
    p = Path('/run/lab-shipper.pid')
    if p.exists():
        try:
            os.kill(int(p.read_text()), 15)
        except (OSError, ValueError):
            pass
        p.unlink(missing_ok=True)


# ---- shipper: doc BIND9 query log that, chuan hoa thanh key=value, day sang Splunk qua TCP ----
# Dinh dang dong (kiem thu thuc te tren BIND 9.18, giong voi ca AXFR, SRV va PTR):
#   "04-Nov-2026 06:47:51.887 client @0x... 127.0.0.1#43345 (_ldap._tcp.corp.local):
#    query: _ldap._tcp.corp.local IN SRV +E(0)K (127.0.0.1)"
MONTHS = {m: i + 1 for i, m in enumerate(
    ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])}
QLINE = re.compile(
    r'^(\d\d)-(\w{3})-(\d{4}) (\d\d:\d\d:\d\d)\.\d+ client(?:\s*@\S+)? '
    r'([0-9a-fA-F:.]+)#\d+ \(([^)]+)\): query: (\S+) IN (\S+)')


def normalize(line):
    m = QLINE.match(line)
    if not m:
        return None
    day, mon, year, t, client_ip, qname_paren, qname, qtype = m.groups()
    mnum = MONTHS.get(mon)
    if not mnum:
        return None
    ts = '%s-%02d-%s %s' % (year, mnum, day, t)
    q = lambda s: s.replace('"', "'")
    return ('%s op=dns_query client_ip=%s qname=%s qtype=%s query="%s IN %s"'
            % (ts, client_ip, q(qname), qtype, q(qname), qtype))


def ship():
    root()
    from collections import deque
    pend, buf = deque(), b''
    off = QUERY_LOG.stat().st_size if QUERY_LOG.exists() else 0
    sock = None
    while True:
        size = QUERY_LOG.stat().st_size if QUERY_LOG.exists() else 0
        if size < off:
            off, buf = 0, b''
        if size > off:
            with QUERY_LOG.open('rb') as f:
                f.seek(off)
                data = f.read(size - off)
            off += len(data)
            buf += data
            *lines, buf = buf.split(b'\n')
            for raw in lines:
                ev = normalize(raw.decode(errors='replace'))
                if ev:
                    pend.append(ev)
        if pend:
            try:
                if sock is None:
                    sock = socket.create_connection((SPL, SHIP_PORT), timeout=5)
                while pend:
                    sock.sendall((pend[0] + '\n').encode())
                    print('shipped:', pend.popleft(), flush=True)
            except OSError:
                if sock:
                    sock.close()
                sock = None
                time.sleep(3)
        time.sleep(.2)


# ------------------------------------------------------------ attacker
def setup_attacker():
    root()
    hosts_add(DNS, 'dns01.corp.local dns01')
    s = socket.socket(); s.settimeout(5)
    require(s.connect_ex((DNS, 53)) == 0, 'Khong ket noi duoc dns01:53 (TCP). Da chay ./start_dns01.sh chua?')
    s.close()
    print('Da them dns01.corp.local vao /etc/hosts. DNS (53) tren dns01 da san sang.')
    print('ATTACKER_READY')


# -------------------------------------------------------------- splunk
CONF = {
    'indexes.conf': '[dns_recon]\nhomePath = $SPLUNK_DB/dns_recon/db\ncoldPath = $SPLUNK_DB/dns_recon/colddb\n'
                    'thawedPath = $SPLUNK_DB/dns_recon/thaweddb\n',
    'inputs.conf': '[tcp://%d]\nindex = dns_recon\nsourcetype = bind:querylog\nconnection_host = none\n' % SHIP_PORT,
    'props.conf': '[bind:querylog]\nSHOULD_LINEMERGE = false\nKV_MODE = auto\nTIME_PREFIX = ^\n'
                  'TIME_FORMAT = %Y-%m-%d %H:%M:%S\nMAX_TIMESTAMP_LOOKAHEAD = 20\n',
    'user-seed.conf': '[user_info]\nUSERNAME = %s\nPASSWORD = %s\n' % (SPLUNK_USER, SPLUNK_PW),
}


def start_splunk():
    root()
    check_disk(1500)
    require(SPLUNK_HOME.exists(), 'Khong thay Splunk tai /opt/splunk (kiem tra buoc build image).')
    local = SPLUNK_HOME / 'etc/system/local'
    local.mkdir(parents=True, exist_ok=True)
    for name, text in CONF.items():
        if name == 'user-seed.conf' and (SPLUNK_HOME / 'etc/passwd').exists():
            continue
        (local / name).write_text(text)
    run(['chown', '-R', 'splunk:splunk', str(SPLUNK_HOME)])
    var = SPLUNK_HOME / 'var'
    var.mkdir(exist_ok=True)
    fstype = out(['stat', '-f', '-c', '%T', str(var)]).strip()
    print('Loai he tap tin cua /opt/splunk/var:', fstype)
    if fstype.startswith(('overlay', 'tmpfs')) and not listening(8089):
        print('CANH BAO: Splunk co the tu choi luu index tren ' + fstype + ' ("unusable filesystem").\n'
              'Image can khai bao VOLUME /opt/splunk/var (dung install.py moi + rebuild).')
    probe = subprocess.run(['sudo', '-u', 'splunk', 'sh', '-c',
                            'mkdir -p /opt/splunk/var/log && touch /opt/splunk/var/log/.w'],
                           text=True, capture_output=True)
    if probe.returncode:
        raise RuntimeError('User splunk khong ghi duoc /opt/splunk/var/log:\n' + probe.stderr)
    run(['sudo', '-u', 'splunk', 'sh', '-c', 'ulimit -f unlimited 2>/dev/null; exec ' + str(SPLUNK_HOME / 'bin/splunk') +
         ' start --accept-license --answer-yes --no-prompt'], stdout=subprocess.DEVNULL)
    wait_for(lambda: listening(8000) and listening(SHIP_PORT) and listening(8089), 180,
             'Splunk chua san sang (8000/8089/%d).' % SHIP_PORT)
    print('Splunk Web: http://%s:8000  (tai khoan %s / %s)' % (SPL, SPLUNK_USER, SPLUNK_PW))
    print('SPLUNK_READY')


def spl(query, host='127.0.0.1'):
    ctx = ssl._create_unverified_context()
    pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pw.add_password(None, 'https://%s:8089' % host, SPLUNK_USER, SPLUNK_PW)
    op = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), urllib.request.HTTPBasicAuthHandler(pw))
    body = urllib.parse.urlencode({'search': 'search ' + query, 'output_mode': 'json',
                                   'earliest_time': '-24h'}).encode()
    rows = []
    with op.open('https://%s:8089/services/search/jobs/export' % host, body, timeout=60) as r:
        for line in r:
            if line.strip():
                res = json.loads(line).get('result')
                if res:
                    rows.append(res)
    return rows


def check_detection(args):
    # Chay tren container attacker, goi Splunk REST API qua mang (172.21.0.30:8089).
    # Ho tro ca hai cach goi (xem HUONG_DAN.txt):
    #   ./check_detection.sh "<cau SPL mot dong>"
    #   ./check_detection.sh @duong_dan_file
    require(len(args) == 1, 'Dung: check_detection.sh "<cau SPL>"  hoac  check_detection.sh @file.txt')
    query = Path(args[0][1:]).read_text().strip() if args[0].startswith('@') else args[0]
    require(query, 'Cau SPL rong.')
    rows, n = [], 0
    for _ in range(12):
        rows = spl(query, host=SPL)
        n = sum(int(r.get('count', 0)) for r in rows) if rows and 'count' in (rows[0] if rows else {}) else len(rows)
        if n > 0:
            break
        time.sleep(5)
    require(n > 0, 'Splunk chua tra ve su kien nao cho truy van nay. Chay du Buoc 1-2 roi thu lai.')
    for r in rows:
        print(r)
    print('DETECTION_CONFIRMED: %d events' % n)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('action')
    p.add_argument('rest', nargs=argparse.REMAINDER)
    a = p.parse_args()
    acts = {'start_dns01': start_dns01, 'ship': ship, 'setup_attacker': setup_attacker,
            'start_splunk': start_splunk}
    if a.action in acts:
        acts[a.action]()
    elif a.action == 'check_detection':
        check_detection(a.rest)
    else:
        raise RuntimeError('Hanh dong khong hop le: ' + a.action)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print('FAILED: ' + str(exc), file=sys.stderr); sys.exit(1)
