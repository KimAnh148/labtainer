#!/usr/bin/env python3
"""Runtime cho bai lab recon-ad-ldap-domain (dc01 / attacker / splunk)."""
import argparse, glob, json, os, re, shutil, socket, ssl, subprocess, sys, time, urllib.parse, urllib.request
from collections import deque
from pathlib import Path

DC, ATK, SPL = '172.20.0.10', '172.20.0.20', '172.20.0.30'
REALM, DOMAIN, BASE = 'CORP.INTERNAL', 'CORP', 'DC=corp,DC=internal'
LOWPRIV, LOWPW, ADMINPW = 'lowpriv-user', 'Labsplunk!2026', 'Adm1n-Lab!2026'
SPLUNK_USER, SPLUNK_PW, SPLUNK_HOME = 'analyst', 'Splunk!Lab2026', Path('/opt/splunk')
SAMBA_LOG, SHIP_PORT, CA_PORT = Path('/var/log/samba/log.samba'), 5514, 8088
SAM = '/var/lib/samba/private/sam.ldb'
CA_DIR = Path('/var/lib/lab-ca')
PSO_DN = 'CN=Lab-Standard-PSO,CN=Password Settings Container,CN=System,' + BASE
PSO_CONTAINER = 'CN=Password Settings Container,CN=System,' + BASE
CLASSES = ('domaindns', 'msds-passwordsettings', 'trusteddomain')


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, **kw)


def out(args, **kw):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, **kw)


def root():
    require(os.geteuid() == 0, 'Hay chay bang script wrapper (can sudo).')


def listening(port):
    return bool(out(['ss', '-H', '-ltn', 'sport', '=', ':' + str(port)]).strip())


def wait_for(cond, seconds, msg):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return
        time.sleep(1)
    raise RuntimeError(msg)


def hosts_add(ip, names):
    p = Path('/etc/hosts')
    if names.split()[0] not in p.read_text():
        with p.open('a') as f:
            f.write('\n' + ip + ' ' + names + '\n')


# ---------------------------------------------------------------- dc01
def ldb_env():
    mods = glob.glob('/usr/lib/*/samba/ldb') + glob.glob('/usr/lib/samba/ldb')
    return dict(os.environ, LDB_MODULES_PATH=mods[0] if mods else '')


def seed_directory():
    sam = lambda *a: run(['samba-tool', *a], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    sam('user', 'create', LOWPRIV, LOWPW, '--given-name=Low', '--surname=Priv')
    sam('domain', 'passwordsettings', 'pso', 'create', 'Lab-Standard-PSO', '10',
        '--complexity=on', '--history-length=12', '--min-pwd-length=12', '--min-pwd-age=1',
        '--max-pwd-age=60', '--account-lockout-threshold=5', '--account-lockout-duration=30',
        '--reset-account-lockout-after=30')
    # Co tinh noi long ACL: Authenticated Users doc duoc PSO (diem yeu cua bai lab).
    for dn, sddl in ((PSO_CONTAINER, '(A;CI;LCRPLO;;;AU)'), (PSO_DN, '(A;;LCRP;;;AU)')):
        sam('dsacl', 'set', '--objectdn=' + dn, '--sddl=' + sddl)
    trust = ('dn: CN=partner.local,CN=System,%s\nobjectClass: top\nobjectClass: leaf\n'
             'objectClass: trustedDomain\ncn: partner.local\ntrustPartner: partner.local\n'
             'flatName: PARTNER\ntrustType: 2\ntrustDirection: 3\ntrustAttributes: 8\n'
             'securityIdentifier: S-1-5-21-2174815223-1234567891-3987654321\n' % BASE)
    run(['ldbadd', '-H', SAM], input=trust, env=ldb_env(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


DONE = Path('/var/lib/samba/.lab-provisioned')


def wipe_samba():
    for d in glob.glob('/var/lib/samba/private/*') + glob.glob('/var/lib/samba/sysvol/*'):
        run(['rm', '-rf', d])
    Path('/etc/samba/smb.conf').unlink(missing_ok=True)


def samba_running():
    return subprocess.run(['pgrep', '-x', 'samba'], stdout=subprocess.DEVNULL).returncode == 0


def serve_ca():
    CA_DIR.mkdir(exist_ok=True)
    ca = Path('/var/lib/samba/private/tls/ca.pem')
    require(ca.exists(), 'Khong thay CA cua Samba: ' + str(ca))
    (CA_DIR / 'corp-ad-ca.pem').write_bytes(ca.read_bytes())  # chi chung chi cong khai
    if not listening(CA_PORT):
        subprocess.Popen([sys.executable, '-m', 'http.server', str(CA_PORT), '--bind', '0.0.0.0',
                          '--directory', str(CA_DIR)], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def check_disk(need_mb):
    free = shutil.disk_usage('/').free // 2**20
    require(free >= need_mb, 'O dia con trong %d MB (can >= %d MB). Giai phong dia tren may Ubuntu '
            '(docker system prune, xoa image/VM khong dung) roi stoplab va chay lai.' % (free, need_mb))


def start_dc01():
    root()
    check_disk(300)
    require(glob.glob('/usr/lib/*/samba/vfs/acl_xattr.so'),
            'Thieu goi samba-vfs-modules trong image. Cai lai bai bang install.py moi va rebuild.')
    hosts_add(DC, 'dc01.corp.internal dc01')
    if not DONE.exists():
        print('Dang provision domain corp.internal (khoang 30-60 giay)...')
        cmd = ['samba-tool', 'domain', 'provision', '--realm=' + REALM, '--domain=' + DOMAIN,
               '--server-role=dc', '--dns-backend=SAMBA_INTERNAL', '--use-rfc2307',
               '--adminpass=' + ADMINPW]
        errors = []
        for extra in ([], ['--option=posix:eadb=/var/lib/samba/private/eadb.tdb']):
            wipe_samba()
            r = subprocess.run(cmd + extra, text=True, capture_output=True)
            if r.returncode == 0:
                break
            errors.append('--- lan thu %d (%s) ---\n%s' % (len(errors) + 1, ' '.join(extra) or 'mac dinh',
                          '\n'.join((r.stdout + r.stderr).strip().splitlines()[-15:])))
            print(errors[-1])
        else:
            wipe_samba()
            raise RuntimeError('Provision that bai (xem loi o tren). Gui nguyen van cho nguoi thiet ke.')
        seed_directory()
        conf = Path('/etc/samba/smb.conf')
        # Level 10: ghi ca 'BindSimple dn' (level 10) lan dong 'SearchRequest ... filter' (level 5).
        conf.write_text(conf.read_text().replace(
            '[global]', '[global]\n\tlog file = /var/log/samba/log.samba\n\tlog level = 10\n'
            '\tmax log size = 0', 1))
        DONE.write_text('ok')
    Path('/var/log/samba').mkdir(parents=True, exist_ok=True)
    if not samba_running():
        # smbd/nmbd/winbindd chay san (dich vu file-server thuong) chiem cong 445 va lam Samba AD tu tat.
        for name in ('smbd', 'nmbd', 'winbindd'):
            subprocess.run(['pkill', '-x', name])
        time.sleep(2)
        run(['samba', '-D'])
    try:
        wait_for(lambda: listening(389) and listening(636), 90, '')
    except RuntimeError:
        errs = subprocess.run("grep -a -i -E 'fail|error|cannot|bind' %s | grep -a -v messaging_dgm | tail -8" % SAMBA_LOG,
                              shell=True, text=True, capture_output=True).stdout
        procs = subprocess.run(['pgrep', '-a', 'smbd|nmbd|winbindd|samba'], text=True, capture_output=True).stdout
        raise RuntimeError('Samba chua lang nghe 389/636.\nTien trinh:\n%s\nLog gan nhat:\n%s' % (procs, errs))
    serve_ca()
    stop_shipper()
    SAMBA_LOG.touch()
    log = open('/var/log/lab-shipper.log', 'a')
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'ship'],
                            start_new_session=True, stdout=log, stderr=log)
    Path('/run/lab-shipper.pid').write_text(str(proc.pid))
    print('Domain corp.internal san sang (LDAP 389, LDAPS 636). Shipper log -> Splunk %s:%d' % (SPL, SHIP_PORT))
    print('DC01_READY')


def stop_shipper():
    p = Path('/run/lab-shipper.pid')
    if p.exists():
        try:
            os.kill(int(p.read_text()), 15)
        except (OSError, ValueError):
            pass
        p.unlink(missing_ok=True)


HDR = re.compile(r'^\[(\d{4})/(\d\d)/(\d\d) (\d\d:\d\d:\d\d)\.\d+,\s*\d+, pid=(\d+)')
SEARCH = re.compile(r'ldapsrv_SearchRequest: LDAP Query:.*? by (\S+) from ipv[46]:\[?([0-9a-fA-F:.]+?)\]?:\d+ '
                    r'filter: \[(.*)\] basedn: \[(.*)\] scope: \[(\w+)\] result: (.*)$', re.M)
BIND = re.compile(r'BindSimple dn: (.+)$', re.M)


def normalize(rec, binds):
    """Doi mot ban ghi log Samba thanh su kien key=value. Mat khau khong co trong log nen khong the lo."""
    m = HDR.match(rec[0])
    if not m:
        return None
    body, pid = '\n'.join(rec[1:]), m.group(5)
    ts = '%s-%s-%s %s' % m.group(1, 2, 3, 4)
    b = BIND.search(body)
    if b:
        binds[pid] = b.group(1).strip()
        return None
    s = SEARCH.search(body)
    if not s:
        return None
    sid, ip, flt, base, scope, result = s.groups()
    q = lambda x: x.replace('"', "'")
    return '%s op=search src_ip=%s bind_dn="%s" sid=%s basedn="%s" scope=%s filter="%s" result="%s"' % (
        ts, ip, q(binds.get(pid, 'unknown')), sid, q(base), scope, q(flt), q(result))


def ship():
    root()
    binds, pend, buf, rec = {}, deque(), b'', []
    off, sock, idle = SAMBA_LOG.stat().st_size, None, time.time()
    while True:
        size = SAMBA_LOG.stat().st_size if SAMBA_LOG.exists() else 0
        if size < off:
            off, buf = 0, b''
        if size > off:
            with SAMBA_LOG.open('rb') as f:
                f.seek(off)
                data = f.read(size - off)
            off += len(data)
            buf += data
            *lines, buf = buf.split(b'\n')
            idle = time.time()
            for raw in lines:
                line = raw.decode(errors='replace')
                if HDR.match(line) and rec:
                    ev = normalize(rec, binds)
                    if ev:
                        pend.append(ev)
                    rec = []
                rec.append(line)
        elif rec and time.time() - idle > 1:
            ev = normalize(rec, binds)
            if ev:
                pend.append(ev)
            rec = []
        if pend:
            try:
                if sock is None:
                    sock = socket.create_connection((SPL, SHIP_PORT), timeout=5)
                while pend:
                    sock.sendall((pend[0] + '\n').encode())
                    print('shipped:', pend.popleft(), flush=True)
            except OSError:
                if sock:
                    sock.close()
                sock = None
                time.sleep(3)
        time.sleep(.3)


# ------------------------------------------------------------ attacker
def setup_attacker():
    root()
    hosts_add(DC, 'dc01.corp.internal dc01')
    url = 'http://%s:%d/corp-ad-ca.pem' % (DC, CA_PORT)
    end = time.time() + 20
    while True:
        try:
            data = urllib.request.urlopen(url, timeout=5).read()
            break
        except OSError:
            require(time.time() < end, 'Khong lay duoc CA tu dc01. Da chay ./start_dc01.sh chua?')
            time.sleep(2)
    Path('/tmp/corp-ad-ca.pem').write_bytes(data)
    os.chmod('/tmp/corp-ad-ca.pem', 0o644)
    s = socket.socket(); s.settimeout(5)
    require(s.connect_ex((DC, 636)) == 0, 'Khong ket noi duoc dc01:636.')
    s.close()
    print('Da luu CA vao /tmp/corp-ad-ca.pem va them dc01.corp.internal vao /etc/hosts.')
    print('ATTACKER_READY')


# -------------------------------------------------------------- splunk
CONF = {
    'indexes.conf': '[ad_recon]\nhomePath = $SPLUNK_DB/ad_recon/db\ncoldPath = $SPLUNK_DB/ad_recon/colddb\n'
                    'thawedPath = $SPLUNK_DB/ad_recon/thaweddb\n',
    'inputs.conf': '[tcp://%d]\nindex = ad_recon\nsourcetype = samba:log\nconnection_host = none\n' % SHIP_PORT,
    'props.conf': '[samba:log]\nSHOULD_LINEMERGE = false\nKV_MODE = auto\nTIME_PREFIX = ^\n'
                  'TIME_FORMAT = %Y-%m-%d %H:%M:%S\nMAX_TIMESTAMP_LOOKAHEAD = 20\n',
    'user-seed.conf': '[user_info]\nUSERNAME = %s\nPASSWORD = %s\n' % (SPLUNK_USER, SPLUNK_PW),
}


def start_splunk():
    root()
    check_disk(1500)
    require(SPLUNK_HOME.exists(), 'Khong thay Splunk tai /opt/splunk (kiem tra buoc build image).')
    local = SPLUNK_HOME / 'etc/system/local'
    local.mkdir(parents=True, exist_ok=True)
    for name, text in CONF.items():
        if name == 'user-seed.conf' and (SPLUNK_HOME / 'etc/passwd').exists():
            continue
        (local / name).write_text(text)
    run(['chown', '-R', 'splunk:splunk', str(SPLUNK_HOME)])
    var = SPLUNK_HOME / 'var'
    var.mkdir(exist_ok=True)
    fstype = out(['stat', '-f', '-c', '%T', str(var)]).strip()
    print('Loai he tap tin cua /opt/splunk/var:', fstype)
    if fstype.startswith(('overlay', 'tmpfs')) and not listening(8089):
        print('CANH BAO: Splunk co the tu choi luu index tren ' + fstype + ' ("unusable filesystem").\n'
              'Image can khai bao VOLUME /opt/splunk/var (dung install.py moi + rebuild).')
    probe = subprocess.run(['sudo', '-u', 'splunk', 'sh', '-c',
                            'mkdir -p /opt/splunk/var/log && touch /opt/splunk/var/log/.w'],
                           text=True, capture_output=True)
    if probe.returncode:
        raise RuntimeError('User splunk khong ghi duoc /opt/splunk/var/log:\n' + probe.stderr + out(
            ['sh', '-c', 'id splunk; ls -ld /opt/splunk /opt/splunk/var; df -h /opt; df -i /opt']))
    run(['sudo', '-u', 'splunk', 'sh', '-c', 'ulimit -f unlimited 2>/dev/null; exec ' + str(SPLUNK_HOME / 'bin/splunk') +
         ' start --accept-license --answer-yes --no-prompt'], stdout=subprocess.DEVNULL)
    wait_for(lambda: listening(8000) and listening(SHIP_PORT) and listening(8089), 180,
             'Splunk chua san sang (8000/8089/%d).' % SHIP_PORT)
    print('Splunk Web: http://%s:8000  (tai khoan %s / %s)' % (SPL, SPLUNK_USER, SPLUNK_PW))
    print('SPLUNK_READY')


def spl(query):
    ctx = ssl._create_unverified_context()
    pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pw.add_password(None, 'https://127.0.0.1:8089', SPLUNK_USER, SPLUNK_PW)
    op = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx),
                                     urllib.request.HTTPBasicAuthHandler(pw))
    body = urllib.parse.urlencode({'search': 'search ' + query, 'output_mode': 'json',
                                   'earliest_time': '-24h'}).encode()
    rows = []
    with op.open('https://127.0.0.1:8089/services/search/jobs/export', body, timeout=60) as r:
        for line in r:
            if line.strip():
                res = json.loads(line).get('result')
                if res:
                    rows.append(res)
    return rows


BASE_SPL = ('index=ad_recon sourcetype=samba:log "search" '
            '("objectClass=domainDNS" OR "objectClass=msDS-PasswordSettings" OR "objectClass=trustedDomain")')
STATS_SPL = BASE_SPL + ' | fillnull value="unknown" src_ip bind_dn filter | stats count by src_ip, bind_dn, filter | where count > 0'


def verify_detection():
    seen, rows = set(), []
    for _ in range(12):
        rows = spl(STATS_SPL)
        text = ' '.join(r.get('filter', '') for r in rows).lower()
        seen = {c for c in CLASSES if c in text}
        if len(seen) == 3:
            break
        time.sleep(5)
    missing = [c for c in CLASSES if c not in seen]
    # Khong in chuoi SPL (chua ten index) khi that bai, de checker .stdout khong cham nham.
    require(not missing, 'Splunk chua thay filter: ' + ', '.join(missing) +
            '. Hay chay du 3 buoc ldapsearch tren attacker roi thu lai.')
    print('SPL:\n ' + STATS_SPL + '\n')
    print('%-16s %-30s %-6s %s' % ('src_ip', 'bind_dn', 'count', 'filter'))
    for r in rows:
        print('%-16s %-30s %-6s %s' % (r.get('src_ip'), r.get('bind_dn'), r.get('count'), r.get('filter')))
    print('\nSplunk da ghi nhan ca 3 truy van LDAP trinh sat (domainDNS, msDS-PasswordSettings, trustedDomain).')
    print('LDAP_RECON_DETECTED')


def main():
    acts = {'start_dc01': start_dc01, 'ship': ship, 'setup_attacker': setup_attacker,
            'start_splunk': start_splunk, 'verify_detection': verify_detection}
    p = argparse.ArgumentParser(); p.add_argument('action', choices=acts); acts[p.parse_args().action]()


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print('FAILED: ' + str(exc), file=sys.stderr); sys.exit(1)
