#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
exec sudo python3 ./lab_runtime.py setup_attacker "$@"
