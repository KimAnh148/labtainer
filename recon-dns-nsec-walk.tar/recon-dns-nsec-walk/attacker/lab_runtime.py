#!/usr/bin/env python3
"""Runtime cho bai lab recon-dns-nsec-walk (dns01 / attacker / splunk)."""
import argparse, json, os, re, shutil, socket, ssl, subprocess, sys, time
import urllib.parse, urllib.request
from pathlib import Path

DNS, ATK, SPL = '172.21.0.10', '172.21.0.20', '172.21.0.30'
ZONE = 'corp.local'
SPLUNK_USER, SPLUNK_PW, SPLUNK_HOME = 'analyst', 'Splunk!Lab2026', Path('/opt/splunk')
QUERY_LOG, SHIP_PORT = Path('/var/log/named/query.log'), 5514
DONE = Path('/var/lib/bind-lab/.provisioned')
NAMED_CONF_LOCAL = Path('/etc/bind/named.conf.local')
ZONE_DIR, KEY_DIR = Path('/etc/bind/zones'), Path('/etc/bind/keys')
ZONE_FILE = ZONE_DIR / 'db.corp.local'
SIGNED_FILE = ZONE_DIR / 'db.corp.local.signed'

# Cac ten noi bo gia lap trong zone (A record). Cong voi dns01 + apex = 16 ten trong chuoi NSEC.
# Mot lan zone walk day du = 16 truy van NSEC (+1 truy van o Buoc 1) > nguong SPL "count > 15".
HOSTS = {
    'dc01': '192.168.1.11', 'dc02': '192.168.1.12', 'mail02': '192.168.1.21',
    'web-prod': '192.168.1.31', 'db01': '192.168.1.41', 'vpn-gw': '192.168.1.51',
    'jenkins-int': '192.168.1.61', 'gitlab': '192.168.1.62', 'hr-portal': '192.168.1.71',
    'backup-old': '192.168.1.81', 'fileserver': '192.168.1.91', 'dev-api': '192.168.1.101',
    'staging': '192.168.1.102', 'monitor': '192.168.1.104',
}

ZONE_TEXT = '''$TTL 3600
@       IN      SOA     dns01.corp.local. admin.corp.local. (
                        2026110600 ; serial
                        3600       ; refresh
                        900        ; retry
                        604800     ; expire
                        3600 )     ; minimum
        IN      NS      dns01.corp.local.
dns01   IN      A       %s
''' % DNS + ''.join('%-12s IN      A       %s\n' % (h, ip) for h, ip in HOSTS.items())

# Zone da ky nam trong file *.signed (dnssec-signzone KHONG dung -3 => NSEC, khong phai NSEC3).
NAMED_LOCAL_TEXT = '''zone "corp.local" {
    type master;
    file "/etc/bind/zones/db.corp.local.signed";
    allow-transfer { none; };
};

logging {
    channel query_log_file {
        file "/var/log/named/query.log" versions 3 size 5m;
        severity info;
        print-time yes;
    };
    category queries { query_log_file; };
};
'''


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, **kw)


def out(args, **kw):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, **kw)


def root():
    require(os.geteuid() == 0, 'Hay chay bang script wrapper (can sudo).')


def listening(port, proto='t'):
    flag = '-ltn' if proto == 't' else '-lun'
    return bool(out(['ss', '-H', flag, 'sport', '=', ':' + str(port)]).strip())


def wait_for(cond, seconds, msg):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return
        time.sleep(1)
    raise RuntimeError(msg)


def check_disk(need_mb):
    free = shutil.disk_usage('/').free // 2**20
    require(free >= need_mb, 'O dia con trong %d MB (can >= %d MB). Giai phong dia tren may Ubuntu '
            '(docker system prune) roi stoplab va chay lai.' % (free, need_mb))


def hosts_add(ip, names):
    p = Path('/etc/hosts')
    if names.split()[0] not in p.read_text():
        with p.open('a') as f:
            f.write('\n' + ip + ' ' + names + '\n')


def named_running():
    # KHONG dung pgrep ten tien trinh: zombie 'named <defunct>' van khop pgrep -x named.
    return listening(53)


def zone_loaded():
    # named DANG CHAY co thuc su biet zone corp.local khong (khac voi file tren dia hop le).
    return subprocess.run(['rndc', 'zonestatus', ZONE], capture_output=True).returncode == 0


def sign_zone():
    """Tao khoa KSK+ZSK va ky zone bang NSEC (khong co -3)."""
    KEY_DIR.mkdir(parents=True, exist_ok=True)
    for old in KEY_DIR.glob('K%s.*' % ZONE):
        old.unlink()
    for extra in ('-f KSK', ''):
        run(['dnssec-keygen', '-q', '-a', 'ECDSAP256SHA256', '-n', 'ZONE', '-K', str(KEY_DIR)]
            + extra.split() + [ZONE], stdout=subprocess.DEVNULL)
    # -S: smart signing (tu them DNSKEY tu thu muc khoa). KHONG dung -3 => chuoi NSEC.
    r = subprocess.run(['dnssec-signzone', '-S', '-K', str(KEY_DIR), '-d', str(KEY_DIR), '-o', ZONE,
                        '-N', 'keep', '-e', 'now+31536000', '-f', str(SIGNED_FILE), str(ZONE_FILE)],
                       text=True, capture_output=True, cwd=str(KEY_DIR))
    require(r.returncode == 0, 'dnssec-signzone loi:\n' + r.stdout + r.stderr)
    text = SIGNED_FILE.read_text()
    require(re.search(r'(?m)^\S+\s+\d+\s+IN\s+NSEC\s', text) or ' NSEC ' in text,
            'Zone da ky khong co ban ghi NSEC.')
    require('NSEC3' not in text, 'Zone da ky dang dung NSEC3 (bai lab can NSEC thuan).')


def start_dns01():
    root()
    check_disk(200)
    fresh = not DONE.exists()
    for tool in ('/usr/sbin/named', '/usr/bin/dnssec-signzone', '/usr/bin/dnssec-keygen'):
        require(Path(tool).exists() or shutil.which(Path(tool).name),
                'Khong tim thay %s (goi bind9/bind9-utils). Kiem tra lai image.' % Path(tool).name)
    hosts_add(DNS, 'dns01.corp.local dns01')
    if fresh:
        Path('/var/lib/bind-lab').mkdir(parents=True, exist_ok=True)
        ZONE_DIR.mkdir(parents=True, exist_ok=True)
        Path('/var/log/named').mkdir(parents=True, exist_ok=True)
        ZONE_FILE.write_text(ZONE_TEXT)
        r = subprocess.run(['named-checkzone', ZONE, str(ZONE_FILE)], text=True, capture_output=True)
        require(r.returncode == 0, 'Zone file loi (%s):\n' % ZONE + r.stdout + r.stderr)
        sign_zone()
        r = subprocess.run(['named-checkzone', ZONE, str(SIGNED_FILE)], text=True, capture_output=True)
        require(r.returncode == 0, 'Zone da ky loi:\n' + r.stdout + r.stderr)
        NAMED_CONF_LOCAL.write_text(NAMED_LOCAL_TEXT)
        r = subprocess.run(['named-checkconf'], text=True, capture_output=True)
        require(r.returncode == 0, 'named.conf loi:\n' + r.stdout + r.stderr)
        run(['chown', '-R', 'bind:bind', str(ZONE_DIR), '/var/log/named'])
        DONE.write_text('ok')
    if named_running() and (fresh or not zone_loaded()):
        # named da chay san tu luc container khoi dong (truoc khi zone/cau hinh duoc ghi) nen
        # khong biet zone corp.local -> SERVFAIL. Dung han roi khoi dong lai de nap dung cau hinh.
        subprocess.run(['rndc', 'stop'], capture_output=True)
        subprocess.run(['pkill', '-x', 'named'], capture_output=True)
        wait_for(lambda: not listening(53), 20, 'named cu khong thoat duoc.')
    if not named_running():
        # Che do daemon THAT (khong '-g'), de named tu fork/detach trong container.
        run(['named', '-u', 'bind', '-c', '/etc/bind/named.conf'])
    try:
        wait_for(lambda: listening(53) and listening(53, 'u'), 60, '')
    except RuntimeError:
        errs = subprocess.run("tail -20 /var/log/syslog 2>/dev/null", shell=True, text=True,
                              capture_output=True).stdout
        procs = subprocess.run(['pgrep', '-a', 'named'], text=True, capture_output=True).stdout
        raise RuntimeError('named chua lang nghe cong 53.\nTien trinh:\n%s\nLog:\n%s' % (procs, errs))
    try:
        wait_for(zone_loaded, 30, '')
    except RuntimeError:
        raise RuntimeError('named dang chay nhung chua nap zone %s (rndc zonestatus loi).' % ZONE)
    if shutil.which('dig'):
        # Kiem tra zone THAT SU tra ve NSEC (truy van nay xay ra truoc khi shipper khoi dong nen
        # khong vao Splunk).
        probe = subprocess.run(['dig', '@127.0.0.1', 'aaaaaaaa.' + ZONE, 'NSEC', '+dnssec', '+norecurse'],
                               text=True, capture_output=True).stdout
        require(re.search(r'\sNSEC\s', probe), 'Zone khong tra ve ban ghi NSEC. Ket qua dig:\n' + probe)
    stop_shipper()
    QUERY_LOG.touch()
    run(['chown', 'bind:bind', str(QUERY_LOG)])
    log = open('/var/log/lab-shipper.log', 'a')
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'ship'],
                            start_new_session=True, stdout=log, stderr=log)
    Path('/run/lab-shipper.pid').write_text(str(proc.pid))
    print('Zone corp.local ky DNSSEC bang NSEC san sang tren dns01 (UDP/TCP 53, %d ten trong zone).'
          % (len(HOSTS) + 2))
    print('Shipper log -> Splunk %s:%d' % (SPL, SHIP_PORT))
    print('DNS01_READY')


def stop_shipper():
    p = Path('/run/lab-shipper.pid')
    if p.exists():
        try:
            os.kill(int(p.read_text()), 15)
        except (OSError, ValueError):
            pass
        p.unlink(missing_ok=True)


# ---- shipper: doc BIND9 query log that, chuan hoa thanh key=value, day sang Splunk qua TCP ----
# Dinh dang dong (BIND 9.18):
#   "06-Nov-2026 06:47:51.887 client @0x... 172.21.0.20#43345 (corp.local):
#    query: corp.local IN NSEC +E(0)DK (172.21.0.10)"
MONTHS = {m: i + 1 for i, m in enumerate(
    ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])}
QLINE = re.compile(
    r'^(\d\d)-(\w{3})-(\d{4}) (\d\d:\d\d:\d\d)\.\d+ client(?:\s*@\S+)? '
    r'([0-9a-fA-F:.]+)#\d+ \(([^)]+)\): query: (\S+) IN (\S+)')


def normalize(line):
    m = QLINE.match(line)
    if not m:
        return None
    day, mon, year, t, client_ip, qname_paren, qname, qtype = m.groups()
    mnum = MONTHS.get(mon)
    if not mnum:
        return None
    ts = '%s-%02d-%s %s' % (year, mnum, day, t)
    q = lambda s: s.replace('"', "'")
    return ('%s op=dns_query client_ip=%s qname=%s qtype=%s query="%s IN %s"'
            % (ts, client_ip, q(qname), qtype, q(qname), qtype))


def ship():
    root()
    from collections import deque
    pend, buf = deque(), b''
    off = QUERY_LOG.stat().st_size if QUERY_LOG.exists() else 0
    sock = None
    while True:
        size = QUERY_LOG.stat().st_size if QUERY_LOG.exists() else 0
        if size < off:
            off, buf = 0, b''
        if size > off:
            with QUERY_LOG.open('rb') as f:
                f.seek(off)
                data = f.read(size - off)
            off += len(data)
            buf += data
            *lines, buf = buf.split(b'\n')
            for raw in lines:
                ev = normalize(raw.decode(errors='replace'))
                if ev:
                    pend.append(ev)
        if pend:
            try:
                if sock is None:
                    sock = socket.create_connection((SPL, SHIP_PORT), timeout=5)
                while pend:
                    sock.sendall((pend[0] + '\n').encode())
                    print('shipped:', pend.popleft(), flush=True)
            except OSError:
                if sock:
                    sock.close()
                sock = None
                time.sleep(3)
        time.sleep(.2)


# ------------------------------------------------------------ attacker
def setup_attacker():
    root()
    hosts_add(DNS, 'dns01.corp.local dns01')
    require(shutil.which('dig'), 'Khong co dig (goi dnsutils). Kiem tra lai image.')
    r = subprocess.run([sys.executable, '-c', 'import dns.message, dns.query'], capture_output=True, text=True)
    require(r.returncode == 0, 'Thieu python3-dnspython tren attacker:\n' + r.stderr)
    s = socket.socket(); s.settimeout(5)
    require(s.connect_ex((DNS, 53)) == 0, 'Khong ket noi duoc dns01:53 (TCP). Da chay ./start_dns01.sh chua?')
    s.close()
    print('Da them dns01.corp.local vao /etc/hosts. DNS (53) tren dns01 da san sang.')
    print('ATTACKER_READY')


# -------------------------------------------------------------- splunk
CONF = {
    'indexes.conf': '[dns_recon]\nhomePath = $SPLUNK_DB/dns_recon/db\ncoldPath = $SPLUNK_DB/dns_recon/colddb\n'
                    'thawedPath = $SPLUNK_DB/dns_recon/thaweddb\n',
    'inputs.conf': '[tcp://%d]\nindex = dns_recon\nsourcetype = bind:querylog\nconnection_host = none\n' % SHIP_PORT,
    'props.conf': '[bind:querylog]\nSHOULD_LINEMERGE = false\nKV_MODE = auto\nTIME_PREFIX = ^\n'
                  'TIME_FORMAT = %Y-%m-%d %H:%M:%S\nMAX_TIMESTAMP_LOOKAHEAD = 20\n',
    'user-seed.conf': '[user_info]\nUSERNAME = %s\nPASSWORD = %s\n' % (SPLUNK_USER, SPLUNK_PW),
}


def start_splunk():
    root()
    check_disk(1500)
    require(SPLUNK_HOME.exists(), 'Khong thay Splunk tai /opt/splunk (kiem tra buoc build image).')
    local = SPLUNK_HOME / 'etc/system/local'
    local.mkdir(parents=True, exist_ok=True)
    for name, text in CONF.items():
        if name == 'user-seed.conf' and (SPLUNK_HOME / 'etc/passwd').exists():
            continue
        (local / name).write_text(text)
    run(['chown', '-R', 'splunk:splunk', str(SPLUNK_HOME)])
    var = SPLUNK_HOME / 'var'
    var.mkdir(exist_ok=True)
    fstype = out(['stat', '-f', '-c', '%T', str(var)]).strip()
    print('Loai he tap tin cua /opt/splunk/var:', fstype)
    if fstype.startswith(('overlay', 'tmpfs')) and not listening(8089):
        print('CANH BAO: Splunk co the tu choi luu index tren ' + fstype + ' ("unusable filesystem").\n'
              'Image can khai bao VOLUME /opt/splunk/var (dung install.py moi + rebuild).')
    probe = subprocess.run(['sudo', '-u', 'splunk', 'sh', '-c',
                            'mkdir -p /opt/splunk/var/log && touch /opt/splunk/var/log/.w'],
                           text=True, capture_output=True)
    if probe.returncode:
        raise RuntimeError('User splunk khong ghi duoc /opt/splunk/var/log:\n' + probe.stderr)
    run(['sudo', '-u', 'splunk', 'sh', '-c', 'ulimit -f unlimited 2>/dev/null; exec ' + str(SPLUNK_HOME / 'bin/splunk') +
         ' start --accept-license --answer-yes --no-prompt'], stdout=subprocess.DEVNULL)
    wait_for(lambda: listening(8000) and listening(SHIP_PORT) and listening(8089), 180,
             'Splunk chua san sang (8000/8089/%d).' % SHIP_PORT)
    print('Splunk Web: http://%s:8000  (tai khoan %s / %s)' % (SPL, SPLUNK_USER, SPLUNK_PW))
    print('SPLUNK_READY')


def spl(query, host='127.0.0.1'):
    ctx = ssl._create_unverified_context()
    pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pw.add_password(None, 'https://%s:8089' % host, SPLUNK_USER, SPLUNK_PW)
    op = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), urllib.request.HTTPBasicAuthHandler(pw))
    body = urllib.parse.urlencode({'search': 'search ' + query, 'output_mode': 'json',
                                   'earliest_time': '-24h'}).encode()
    rows = []
    with op.open('https://%s:8089/services/search/jobs/export' % host, body, timeout=60) as r:
        for line in r:
            if line.strip():
                res = json.loads(line).get('result')
                if res:
                    rows.append(res)
    return rows


def check_detection(args):
    # Chay tren container attacker, goi Splunk REST API qua mang (172.21.0.30:8089).
    # Ho tro ca hai cach goi (xem HUONG_DAN.txt):
    #   ./check_detection.sh "<cau SPL nhieu dong duoc>"
    #   ./check_detection.sh @duong_dan_file
    require(len(args) == 1, 'Dung: check_detection.sh "<cau SPL>"  hoac  check_detection.sh @file.txt')
    query = Path(args[0][1:]).read_text().strip() if args[0].startswith('@') else args[0].strip()
    require(query, 'Cau SPL rong.')
    rows, n = [], 0
    for _ in range(12):
        rows = spl(query, host=SPL)
        n = sum(int(r.get('count', 0)) for r in rows) if rows and 'count' in rows[0] else len(rows)
        if n > 0:
            break
        time.sleep(5)
    require(n > 0, 'Splunk chua tra ve su kien nao cho truy van nay. Chay du Buoc 1-2 roi thu lai.')
    for r in rows:
        print(r)
    print('DETECTION_CONFIRMED: %d events' % n)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('action')
    p.add_argument('rest', nargs=argparse.REMAINDER)
    a = p.parse_args()
    acts = {'start_dns01': start_dns01, 'ship': ship, 'setup_attacker': setup_attacker,
            'start_splunk': start_splunk}
    if a.action in acts:
        acts[a.action]()
    elif a.action == 'check_detection':
        check_detection(a.rest)
    else:
        raise RuntimeError('Hanh dong khong hop le: ' + a.action)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print('FAILED: ' + str(exc), file=sys.stderr); sys.exit(1)
