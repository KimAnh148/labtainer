#!/usr/bin/env python3
"""nsec_walk.py <zone> <dns-server>

Liet ke toan bo ten trong mot zone DNSSEC dung NSEC bang ky thuat "zone walking".
Sinh vien hoan thien vong lap trong ham walk() (cho co chu TODO).

Vi du:  python3 nsec_walk.py corp.local dns01 | tee nsec_walk_result.txt
"""
import socket
import sys

import dns.flags
import dns.message
import dns.name
import dns.query
import dns.rdatatype


def ask_nsec(server_ip, qname):
    """Gui truy van NSEC (co bit DO) toi server, tra ve dns.message."""
    q = dns.message.make_query(qname, dns.rdatatype.NSEC, want_dnssec=True)
    resp = dns.query.udp(q, server_ip, timeout=3)
    if resp.flags & dns.flags.TC:                  # phan hoi bi cat -> thu lai bang TCP
        resp = dns.query.tcp(q, server_ip, timeout=3)
    return resp


def nsec_records(resp):
    """Tra ve danh sach (owner, next_name, types) cua MOI ban ghi NSEC trong phan ANSWER
    va AUTHORITY cua phan hoi.
      owner     : ten so huu ban ghi NSEC (dns.name.Name)
      next_name : truong 'next domain name' (dns.name.Name)
      types     : danh sach loai ban ghi ton tai tai owner, vi du ['A', 'RRSIG', 'NSEC']
    """
    found = []
    for section in (resp.answer, resp.authority):
        for rrset in section:
            if rrset.rdtype == dns.rdatatype.NSEC:
                for rd in rrset:
                    found.append((rrset.name, rd.next, rd.to_text().split()[1:]))
    return found


def walk(zone, server_ip):
    """Di bo qua chuoi NSEC cua zone, in ra moi ten tim duoc (mot ten mot dong).

    Y tuong:
      1. Bat dau tai apex cua zone (ten zone).
      2. Hoi ban ghi NSEC cua ten hien tai  -> lay duoc 'next domain name'.
      3. In ten hien tai, coi 'next domain name' la ten hien tai moi, lap lai buoc 2.
      4. Dung khi 'next domain name' quay ve apex (chuoi NSEC la mot vong khep kin).
    Goi y: dung ask_nsec() va nsec_records(); chi lay ban ghi co owner == ten dang hoi;
    nho chong lap vo han neu server tra ve ket qua la.
    """
    apex = dns.name.from_text(zone)
    # TODO: viet vong lap zone-walk tai day (khoang 10-12 dong).
    raise NotImplementedError('Hoan thien vong lap zone-walk trong ham walk() cua nsec_walk.py')


def main():
    if len(sys.argv) != 3:
        sys.exit('Dung: python3 nsec_walk.py <zone> <dns-server>')
    zone, server = sys.argv[1], sys.argv[2]
    walk(zone, socket.gethostbyname(server))


if __name__ == '__main__':
    main()
