#!/usr/bin/env python3
"""Runtime cho bai lab recon-ad-sysvol-gpp (dc01 / attacker / splunk)."""
import argparse, base64, glob, json, os, re, socket, ssl, subprocess, sys, time
import urllib.parse, urllib.request
from pathlib import Path

DC, ATK, SPL = '172.20.0.10', '172.20.0.20', '172.20.0.30'
REALM, DOMAIN, BASE = 'CORP.INTERNAL', 'CORP', 'DC=corp,DC=internal'
ADMINPW = 'Adm1n-Lab!2026'
LOWPRIV, LOWPW = 'lowpriv-user', 'Labsplunk!2026'
SPLUNK_USER, SPLUNK_PW, SPLUNK_HOME = 'analyst', 'Splunk!Lab2026', Path('/opt/splunk')
SAMBA_LOG, SHIP_PORT = Path('/var/log/samba/log.samba'), 5514
SAM = '/var/lib/samba/private/sam.ldb'
DONE = Path('/var/lib/samba/.lab-provisioned')
SYSVOL = Path('/var/lib/samba/sysvol')
GPO_GUID = '{B4A1F2E3-9C7D-4A3E-8F21-6D5C4B3A2E10}'
GPP_PASSWORD = 'SvcAcct!Gpp2026'          # mat khau "bi lo" ma sinh vien phai tim ra
# Khoa AES-256 cong khai cho GPP cpassword, Microsoft cong bo trong MS14-025 / MSDN 2.2.1.1.4.
GPP_KEY = bytes.fromhex('4e9906e8fcb66cc9faf49310620ffee8f496e806cc057990209b09a433b66c1b')


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, **kw)


def out(args, **kw):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, **kw)


def root():
    require(os.geteuid() == 0, 'Hay chay bang script wrapper (can sudo).')


def listening(port):
    return bool(out(['ss', '-H', '-ltn', 'sport', '=', ':' + str(port)]).strip())


def wait_for(cond, seconds, msg):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return
        time.sleep(1)
    raise RuntimeError(msg)


def check_disk(need_mb):
    import shutil
    free = shutil.disk_usage('/').free // 2**20
    require(free >= need_mb, 'O dia con trong %d MB (can >= %d MB). Giai phong dia tren may Ubuntu '
            '(docker system prune) roi stoplab va chay lai.' % (free, need_mb))


def hosts_add(ip, names):
    p = Path('/etc/hosts')
    if names.split()[0] not in p.read_text():
        with p.open('a') as f:
            f.write('\n' + ip + ' ' + names + '\n')


def wipe_samba():
    for d in glob.glob('/var/lib/samba/private/*') + glob.glob('/var/lib/samba/sysvol/*'):
        run(['rm', '-rf', d])
    Path('/etc/samba/smb.conf').unlink(missing_ok=True)


def samba_running():
    return subprocess.run(['pgrep', '-x', 'samba'], stdout=subprocess.DEVNULL).returncode == 0


# ---- GPP cpassword: ma hoa/giai ma dung dung thuat toan va khoa cong khai MS14-025 ----
def gpp_encrypt(password):
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
    data = pad(password.encode('utf-16-le'), 16)
    ct = AES.new(GPP_KEY, AES.MODE_CBC, iv=b'\x00' * 16).encrypt(data)
    return base64.b64encode(ct).decode().rstrip('=').replace('+', '-').replace('/', '_')


def gpp_decrypt(cpassword):
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    b64 = cpassword.replace('-', '+').replace('_', '/')
    b64 += '=' * (-len(b64) % 4)
    pt = unpad(AES.new(GPP_KEY, AES.MODE_CBC, iv=b'\x00' * 16).decrypt(base64.b64decode(b64)), 16)
    return pt.decode('utf-16-le')


def seed_sysvol_gpo():
    base = SYSVOL / 'corp.internal/Policies' / GPO_GUID
    (base / 'MACHINE/Preferences/Groups').mkdir(parents=True, exist_ok=True)
    (base / 'MACHINE/Microsoft/Windows NT/SecEdit').mkdir(parents=True, exist_ok=True)
    cpw = gpp_encrypt(GPP_PASSWORD)
    groups_xml = '''<?xml version="1.0" encoding="utf-8"?>
<Groups clsid="{3125E937-EB16-4b4c-9934-544FC6D24D26}">
\t<User clsid="{DF5F1855-51E5-4d24-8B1A-D9BDE98BA1D1}" name="svc-backup" image="2" changed="2026-01-15 09:12:03" uid="{B1A2C3D4-E5F6-4789-ABCD-1234567890AB}">
\t\t<Properties action="U" newName="" fullName="" description="Local service account for backup agent" cpassword="%s" changeLogon="0" noChange="0" neverExpires="1" acctDisabled="0" userName="svc-backup"/>
\t</User>
</Groups>
''' % cpw
    gpttmpl = '''[Unicode]
Unicode=yes
[System Access]
MinimumPasswordAge = 1
MaximumPasswordAge = 42
MinimumPasswordLength = 7
PasswordComplexity = 1
LockoutBadCount = 5
[Version]
signature="$CHICAGO$"
Revision=1
'''
    (base / 'MACHINE/Preferences/Groups/Groups.xml').write_text(groups_xml)
    (base / 'MACHINE/Microsoft/Windows NT/SecEdit/GptTmpl.inf').write_text(gpttmpl)
    (base / 'GPT.INI').write_text('[General]\nVersion=65543\ndisplayName=Backup Service Account Policy\n')
    run(['chown', '-R', 'root:root', str(base)])
    run(['chmod', '-R', 'a+rX', str(base)])


def start_dc01():
    root()
    check_disk(300)
    require(glob.glob('/usr/lib/*/samba/vfs/acl_xattr.so'),
            'Thieu goi samba-vfs-modules trong image. Cai lai bang install.py moi va rebuild.')
    require(glob.glob('/usr/lib/*/samba/vfs/full_audit.so'),
            'Thieu module full_audit (goi samba-vfs-modules).')
    hosts_add(DC, 'dc01.corp.internal dc01')
    if not DONE.exists():
        print('Dang provision domain corp.internal (khoang 30-60 giay)...')
        cmd = ['samba-tool', 'domain', 'provision', '--realm=' + REALM, '--domain=' + DOMAIN,
               '--server-role=dc', '--dns-backend=SAMBA_INTERNAL', '--use-rfc2307',
               '--adminpass=' + ADMINPW]
        errors = []
        for extra in ([], ['--option=posix:eadb=/var/lib/samba/private/eadb.tdb']):
            wipe_samba()
            r = subprocess.run(cmd + extra, text=True, capture_output=True)
            if r.returncode == 0:
                break
            errors.append('--- lan thu %d (%s) ---\n%s' % (len(errors) + 1, ' '.join(extra) or 'mac dinh',
                          '\n'.join((r.stdout + r.stderr).strip().splitlines()[-15:])))
            print(errors[-1])
        else:
            wipe_samba()
            raise RuntimeError('Provision that bai (xem loi o tren). Gui nguyen van cho nguoi thiet ke.')
        run(['samba-tool', 'user', 'create', LOWPRIV, LOWPW],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        conf = Path('/etc/samba/smb.conf')
        text = conf.read_text()
        # Bat audit truy cap file tren share [sysvol] bang module full_audit cua Samba.
        # QUAN TRONG (kiem thu thuc te, sai voi suy doan ban dau):
        #  - Phai giu nguyen 'dfs_samba4 acl_xattr' da co san o muc global, neu khong AD DC
        #    hong ACL/DFS cho sysvol. 'vfs objects' o muc share SE GHI DE, khong gop, nen phai
        #    liet ke du: full_audit roi den dfs_samba4 acl_xattr.
        #  - full_audit:syslog = no de ghi vao CHINH log.samba (thay vi can rsyslogd, thu
        #    thuong khong co san trong container toi gian) -> dong ghi nhu mot DEBUG muc 1.
        #  - 'open' KHONG du: smbclient hien dai dung SMB2/3, goi hook 'create_file' chu khong
        #    phai 'open'. Phai liet ke ca hai (va 'pread' cho thao tac doc noi dung).
        #  - log level = 1 la du (do_log() ghi o muc 1); KHONG can bat lop debug rieng
        #    'full_audit:N' nhu tai lieu samba cu de cap, cai do khong co tac dung o day.
        old = "[sysvol]\n\tpath = /var/lib/samba/sysvol\n\tread only = No\n"
        require(text.count(old) >= 1, 'Khong tim thay khoi [sysvol] mac dinh trong smb.conf.')
        new = (old + "\tvfs objects = full_audit dfs_samba4 acl_xattr\n"
               "\tfull_audit:prefix = %u|%I\n\tfull_audit:success = create_file open pread\n"
               "\tfull_audit:failure = none\n\tfull_audit:syslog = no\n")
        text = text.replace(old, new, 1)
        text = text.replace('[global]', '[global]\n\tlog file = /var/log/samba/log.samba\n'
                            '\tlog level = 1\n\tmax log size = 0', 1)
        conf.write_text(text)
        DONE.write_text('ok')
    Path('/var/log/samba').mkdir(parents=True, exist_ok=True)
    if not samba_running():
        for name in ('smbd', 'nmbd', 'winbindd'):
            subprocess.run(['pkill', '-x', name])
        time.sleep(2)
        run(['samba', '-D'])
    try:
        wait_for(lambda: listening(445) and listening(389), 90, '')
    except RuntimeError:
        errs = subprocess.run("grep -a -i -E 'fail|error|cannot|bind' %s | tail -8" % SAMBA_LOG,
                              shell=True, text=True, capture_output=True).stdout
        procs = subprocess.run(['pgrep', '-a', 'smbd|nmbd|winbindd|samba'], text=True, capture_output=True).stdout
        raise RuntimeError('Samba chua lang nghe 445/389.\nTien trinh:\n%s\nLog gan nhat:\n%s' % (procs, errs))
    if not (SYSVOL / 'corp.internal/Policies' / GPO_GUID / 'MACHINE/Preferences/Groups/Groups.xml').exists():
        seed_sysvol_gpo()
    stop_shipper()
    SAMBA_LOG.touch()
    log = open('/var/log/lab-shipper.log', 'a')
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'ship'],
                            start_new_session=True, stdout=log, stderr=log)
    Path('/run/lab-shipper.pid').write_text(str(proc.pid))
    print('Domain corp.internal san sang (SMB 445, LDAP 389). SYSVOL co GPO chua GPP cpassword.')
    print('Shipper log -> Splunk %s:%d' % (SPL, SHIP_PORT))
    print('DC01_READY')


def stop_shipper():
    p = Path('/run/lab-shipper.pid')
    if p.exists():
        try:
            os.kill(int(p.read_text()), 15)
        except (OSError, ValueError):
            pass
        p.unlink(missing_ok=True)


# ---- shipper: doc dong smbd_audit that (full_audit:syslog=no -> ghi vao log.samba), ----
# ---- chuan hoa thanh key=value, day sang Splunk qua TCP ----
# Dinh dang dong (kiem thu thuc te tren Samba 4.19.5):
#   PREFIX(=user|ip)|create_file|ok|0xMASK|dir_hoac_file|disposition|duong_dan
#   PREFIX(=user|ip)|pread|ok|duong_dan
HDR = re.compile(r'^\[(\d{4})/(\d\d)/(\d\d) (\d\d:\d\d:\d\d)')
CREATE = re.compile(r"^\s*([^|\s]+)\|([0-9a-fA-F.:]+)\|create_file\|(ok|fail\S*)\|0x[0-9a-fA-F]+\|"
                    r"(?:dir|file)\|\w+\|(.+)$")
PREAD = re.compile(r"^\s*([^|\s]+)\|([0-9a-fA-F.:]+)\|pread\|(ok|fail\S*)\|(.+)$")


def _mk_event(ts, operation, user, ip, result, path):
    user = user.split('\\')[-1]  # bo tien to domain (vd CORP\john.doe -> john.doe)
    share = 'SYSVOL' if '/sysvol/' in path.lower() else 'UNKNOWN'
    path = path.replace('"', "'")
    return ('%s op=smb_audit operation=%s share=%s user=%s src_ip=%s result=%s path="%s"'
            % (ts, operation, share, user, ip, result, path))


def ship():
    root()
    from collections import deque
    pend, buf, last_ts = deque(), b'', time.strftime('%Y-%m-%d %H:%M:%S')
    off, sock = SAMBA_LOG.stat().st_size, None
    while True:
        size = SAMBA_LOG.stat().st_size if SAMBA_LOG.exists() else 0
        if size < off:
            off, buf = 0, b''
        if size > off:
            with SAMBA_LOG.open('rb') as f:
                f.seek(off)
                data = f.read(size - off)
            off += len(data)
            buf += data
            *lines, buf = buf.split(b'\n')
            for raw in lines:
                line = raw.decode(errors='replace')
                m = HDR.match(line)
                if m:
                    last_ts = '%s-%s-%s %s' % m.group(1, 2, 3, 4)
                    continue
                s = CREATE.match(line)
                if s:
                    user, ip, result, path = s.groups()
                    pend.append(_mk_event(last_ts, 'create_file', user, ip, result, path))
                    continue
                s = PREAD.match(line)
                if s:
                    user, ip, result, path = s.groups()
                    pend.append(_mk_event(last_ts, 'pread', user, ip, result, path))
                    continue
        if pend:
            try:
                if sock is None:
                    sock = socket.create_connection((SPL, SHIP_PORT), timeout=5)
                while pend:
                    sock.sendall((pend[0] + '\n').encode())
                    print('shipped:', pend.popleft(), flush=True)
            except OSError:
                if sock:
                    sock.close()
                sock = None
                time.sleep(3)
        time.sleep(.2)


# ------------------------------------------------------------ attacker
def setup_attacker():
    root()
    hosts_add(DC, 'dc01.corp.internal dc01')
    s = socket.socket(); s.settimeout(5)
    require(s.connect_ex((DC, 445)) == 0, 'Khong ket noi duoc dc01:445 (SMB). Da chay ./start_dc01.sh chua?')
    s.close()
    print('Da them dc01.corp.internal vao /etc/hosts. SMB (445) tren dc01 da san sang.')
    print('Tai khoan domain user thuong: %s / %s' % (LOWPRIV, LOWPW))
    print('ATTACKER_READY')


def gpp_decrypt_cli(args):
    # Tuong duong cong cu gpp-decrypt (ban goc la gem Ruby cua Kali, khong co san trong moi
    # truong nay): nhan mot chuoi cpassword, in ra mat khau da giai ma.
    require(len(args) == 1, 'Dung: gpp-decrypt "<cpassword>"')
    try:
        print(gpp_decrypt(args[0]))
    except Exception as exc:
        raise RuntimeError('Khong giai ma duoc cpassword nay: ' + str(exc))


# -------------------------------------------------------------- splunk
CONF = {
    'indexes.conf': '[ad_recon]\nhomePath = $SPLUNK_DB/ad_recon/db\ncoldPath = $SPLUNK_DB/ad_recon/colddb\n'
                    'thawedPath = $SPLUNK_DB/ad_recon/thaweddb\n',
    'inputs.conf': '[tcp://%d]\nindex = ad_recon\nsourcetype = samba:smb_audit\nconnection_host = none\n' % SHIP_PORT,
    'props.conf': '[samba:smb_audit]\nSHOULD_LINEMERGE = false\nKV_MODE = auto\nTIME_PREFIX = ^\n'
                  'TIME_FORMAT = %Y-%m-%d %H:%M:%S\nMAX_TIMESTAMP_LOOKAHEAD = 20\n',
    'user-seed.conf': '[user_info]\nUSERNAME = %s\nPASSWORD = %s\n' % (SPLUNK_USER, SPLUNK_PW),
}


def start_splunk():
    root()
    check_disk(1500)
    require(SPLUNK_HOME.exists(), 'Khong thay Splunk tai /opt/splunk (kiem tra buoc build image).')
    local = SPLUNK_HOME / 'etc/system/local'
    local.mkdir(parents=True, exist_ok=True)
    for name, text in CONF.items():
        if name == 'user-seed.conf' and (SPLUNK_HOME / 'etc/passwd').exists():
            continue
        (local / name).write_text(text)
    run(['chown', '-R', 'splunk:splunk', str(SPLUNK_HOME)])
    var = SPLUNK_HOME / 'var'
    var.mkdir(exist_ok=True)
    fstype = out(['stat', '-f', '-c', '%T', str(var)]).strip()
    print('Loai he tap tin cua /opt/splunk/var:', fstype)
    if fstype.startswith(('overlay', 'tmpfs')) and not listening(8089):
        print('CANH BAO: Splunk co the tu choi luu index tren ' + fstype + ' ("unusable filesystem").\n'
              'Image can khai bao VOLUME /opt/splunk/var (dung install.py moi + rebuild).')
    probe = subprocess.run(['sudo', '-u', 'splunk', 'sh', '-c',
                            'mkdir -p /opt/splunk/var/log && touch /opt/splunk/var/log/.w'],
                           text=True, capture_output=True)
    if probe.returncode:
        raise RuntimeError('User splunk khong ghi duoc /opt/splunk/var/log:\n' + probe.stderr)
    run(['sudo', '-u', 'splunk', 'sh', '-c', 'ulimit -f unlimited 2>/dev/null; exec ' + str(SPLUNK_HOME / 'bin/splunk') +
         ' start --accept-license --answer-yes --no-prompt'], stdout=subprocess.DEVNULL)
    wait_for(lambda: listening(8000) and listening(SHIP_PORT) and listening(8089), 180,
             'Splunk chua san sang (8000/8089/%d).' % SHIP_PORT)
    print('Splunk Web: http://%s:8000  (tai khoan %s / %s)' % (SPL, SPLUNK_USER, SPLUNK_PW))
    print('SPLUNK_READY')


def spl(query, host='127.0.0.1'):
    ctx = ssl._create_unverified_context()
    pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pw.add_password(None, 'https://%s:8089' % host, SPLUNK_USER, SPLUNK_PW)
    op = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), urllib.request.HTTPBasicAuthHandler(pw))
    body = urllib.parse.urlencode({'search': 'search ' + query, 'output_mode': 'json',
                                   'earliest_time': '-24h'}).encode()
    rows = []
    with op.open('https://%s:8089/services/search/jobs/export' % host, body, timeout=60) as r:
        for line in r:
            if line.strip():
                res = json.loads(line).get('result')
                if res:
                    rows.append(res)
    return rows


def check_detection(args):
    # Chay tren container attacker, goi Splunk REST API qua mang (172.20.0.30:8089).
    # Ho tro ca hai cach goi (xem HUONG_DAN.txt ve ly do):
    #   ./check_detection.sh "<cau SPL mot dong>"
    #   ./check_detection.sh @duong_dan_file
    require(len(args) == 1, 'Dung: check_detection.sh "<cau SPL>"  hoac  check_detection.sh @file.txt')
    query = Path(args[0][1:]).read_text().strip() if args[0].startswith('@') else args[0]
    require(query, 'Cau SPL rong.')
    rows, n = [], 0
    for _ in range(12):
        rows = spl(query, host=SPL)
        n = sum(int(r.get('count', 0)) for r in rows) if rows and 'count' in (rows[0] if rows else {}) else len(rows)
        if n > 0:
            break
        time.sleep(5)
    require(n > 0, 'Splunk chua tra ve su kien nao cho truy van nay. Chay du Buoc 1-2 roi thu lai.')
    for r in rows:
        print(r)
    print('DETECTION_CONFIRMED: %d events' % n)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('action')
    p.add_argument('rest', nargs=argparse.REMAINDER)
    a = p.parse_args()
    acts = {'start_dc01': start_dc01, 'ship': ship, 'setup_attacker': setup_attacker,
            'start_splunk': start_splunk}
    if a.action in acts:
        acts[a.action]()
    elif a.action == 'gpp_decrypt':
        gpp_decrypt_cli(a.rest)
    elif a.action == 'check_detection':
        check_detection(a.rest)
    else:
        raise RuntimeError('Hanh dong khong hop le: ' + a.action)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print('FAILED: ' + str(exc), file=sys.stderr); sys.exit(1)
