#!/usr/bin/env python3
"""Runtime cho bai lab recon-ad-kerb-preauth (dc01 / attacker / splunk)."""
import argparse, datetime, glob, json, os, random, re, socket, ssl, subprocess, sys, time
import urllib.parse, urllib.request
from pathlib import Path

DC, ATK, SPL = '172.20.0.10', '172.20.0.20', '172.20.0.30'
REALM, DOMAIN, BASE = 'CORP.INTERNAL', 'CORP', 'DC=corp,DC=internal'
ADMINPW = 'Adm1n-Lab!2026'
USERPW = 'ChangeMe!2026x'
SPLUNK_USER, SPLUNK_PW, SPLUNK_HOME = 'analyst', 'Splunk!Lab2026', Path('/opt/splunk')
SAMBA_LOG, SHIP_PORT = Path('/var/log/samba/log.samba'), 5514
SAM = '/var/lib/samba/private/sam.ldb'
DONE = Path('/var/lib/samba/.lab-provisioned')
# 15 tai khoan hop le, KHONG tiet lo cho sinh vien (chi dung de seed va de doi chieu khi cham).
VALID_USERS = ['john.doe', 'mary.smith', 'alex.ng', 'peter.vu', 'linh.tran', 'duc.hoang',
               'mai.pham', 'tuan.le', 'hai.dang', 'kim.nguyen', 'bao.tran', 'son.le',
               'lan.vu', 'quang.do', 'yen.chau']


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, **kw)


def out(args, **kw):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, **kw)


def root():
    require(os.geteuid() == 0, 'Hay chay bang script wrapper (can sudo).')


def listening(port):
    return bool(out(['ss', '-H', '-ltn', 'sport', '=', ':' + str(port)]).strip())


def wait_for(cond, seconds, msg):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return
        time.sleep(1)
    raise RuntimeError(msg)


def check_disk(need_mb):
    import shutil
    free = shutil.disk_usage('/').free // 2**20
    require(free >= need_mb, 'O dia con trong %d MB (can >= %d MB). Giai phong dia tren may Ubuntu '
            '(docker system prune) roi stoplab va chay lai.' % (free, need_mb))


def hosts_add(ip, names):
    p = Path('/etc/hosts')
    if names.split()[0] not in p.read_text():
        with p.open('a') as f:
            f.write('\n' + ip + ' ' + names + '\n')


def wipe_samba():
    for d in glob.glob('/var/lib/samba/private/*') + glob.glob('/var/lib/samba/sysvol/*'):
        run(['rm', '-rf', d])
    Path('/etc/samba/smb.conf').unlink(missing_ok=True)


def samba_running():
    return subprocess.run(['pgrep', '-x', 'samba'], stdout=subprocess.DEVNULL).returncode == 0


def seed_directory():
    for u in VALID_USERS:
        subprocess.run(['samba-tool', 'user', 'create', u, USERPW],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def start_dc01():
    root()
    check_disk(300)
    require(glob.glob('/usr/lib/*/samba/vfs/acl_xattr.so'),
            'Thieu goi samba-vfs-modules trong image. Cai lai bang install.py moi va rebuild.')
    hosts_add(DC, 'dc01.corp.internal dc01')
    if not DONE.exists():
        print('Dang provision domain corp.internal (khoang 30-60 giay)...')
        cmd = ['samba-tool', 'domain', 'provision', '--realm=' + REALM, '--domain=' + DOMAIN,
               '--server-role=dc', '--dns-backend=SAMBA_INTERNAL', '--use-rfc2307',
               '--adminpass=' + ADMINPW]
        errors = []
        for extra in ([], ['--option=posix:eadb=/var/lib/samba/private/eadb.tdb']):
            wipe_samba()
            r = subprocess.run(cmd + extra, text=True, capture_output=True)
            if r.returncode == 0:
                break
            errors.append('--- lan thu %d (%s) ---\n%s' % (len(errors) + 1, ' '.join(extra) or 'mac dinh',
                          '\n'.join((r.stdout + r.stderr).strip().splitlines()[-15:])))
            print(errors[-1])
        else:
            wipe_samba()
            raise RuntimeError('Provision that bai (xem loi o tren). Gui nguyen van cho nguoi thiet ke.')
        seed_directory()
        conf = Path('/etc/samba/smb.conf')
        # Dinh dang dong Kerberos KHAC NHAU giua cac ban Samba (da kiem thu thuc te ca hai):
        #   Samba >= 4.19: mot dong 'AS-REQ ERR_PREAUTH_REQUIRED ipv4:... user@REALM krbtgt/...'
        #   Samba 4.15.x : nhieu dong, dong mo 'AS-REQ user@REALM from ipv4:...', dong dong rieng
        #                  'No preauth found...' hoac 'UNKNOWN -- ...: no such entry found in hdb'.
        # kerberos:5 chay dung tren ca hai (4.19 chi can kerberos:3; dung 5 de chac chan tren 4.15).
        conf.write_text(conf.read_text().replace(
            '[global]', '[global]\n\tlog file = /var/log/samba/log.samba\n\tlog level = 1 kerberos:5\n'
            '\tmax log size = 0\n\t# KDC khong khoa/throttle AS-REQ thieu preauth: day la hanh vi mac dinh,\n'
            '\t# khong phai cau hinh rieng (loi PREAUTH_REQUIRED khong tinh la mot lan dang nhap sai).', 1))
        DONE.write_text('ok')
    Path('/var/log/samba').mkdir(parents=True, exist_ok=True)
    if not samba_running():
        for name in ('smbd', 'nmbd', 'winbindd'):
            subprocess.run(['pkill', '-x', name])
        time.sleep(2)
        run(['samba', '-D'])
    try:
        wait_for(lambda: listening(88) and listening(389), 90, '')
    except RuntimeError:
        errs = subprocess.run("grep -a -i -E 'fail|error|cannot|bind' %s | tail -8" % SAMBA_LOG,
                              shell=True, text=True, capture_output=True).stdout
        procs = subprocess.run(['pgrep', '-a', 'smbd|nmbd|winbindd|samba'], text=True, capture_output=True).stdout
        raise RuntimeError('Samba chua lang nghe 88/389.\nTien trinh:\n%s\nLog gan nhat:\n%s' % (procs, errs))
    stop_shipper()
    SAMBA_LOG.touch()
    log = open('/var/log/lab-shipper.log', 'a')
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'ship'],
                            start_new_session=True, stdout=log, stderr=log)
    Path('/run/lab-shipper.pid').write_text(str(proc.pid))
    print('Domain corp.internal san sang (Kerberos 88, LDAP 389). Shipper log -> Splunk %s:%d' % (SPL, SHIP_PORT))
    print('DC01_READY')


def stop_shipper():
    p = Path('/run/lab-shipper.pid')
    if p.exists():
        try:
            os.kill(int(p.read_text()), 15)
        except (OSError, ValueError):
            pass
        p.unlink(missing_ok=True)


# ---- shipper: doc log Samba, chuan hoa AS-REQ, day sang Splunk qua TCP.
# Samba ghi dong nay theo 2 KIEU KHAC NHAU tuy phien ban (kiem thu thuc te tren ca hai):
#   - Samba >= 4.19 (mot dong):  "AS-REQ ERR_PREAUTH_REQUIRED ipv4:IP:PORT user@REALM krbtgt/..."
#   - Samba 4.15.x  (nhieu dong): dong "AS-REQ user@REALM from ipv4:IP:PORT for krbtgt/..." mo dau,
#     roi mot dong KET THUC rieng xuat hien sau (co the cach vai dong log khac xen giua):
#       "No preauth found, returning PREAUTH-REQUIRED -- user@REALM"   (user hop le)
#       "UNKNOWN -- user@REALM: no such entry found in hdb"            (user khong ton tai)
# Shipper xu ly tung dong mot (khong gom theo khoi pid), ho tro ca hai kieu.
HDR = re.compile(r'^\[(\d{4})/(\d\d)/(\d\d) (\d\d:\d\d:\d\d)')
ONELINE = re.compile(r"Kerberos: AS-REQ (ERR_\S+) ipv[46]:\[?([0-9a-fA-F:.]+?)\]?:\d+ "
                     r"([^@]+)@(\S+?) krbtgt")
OPEN_REQ = re.compile(r"Kerberos: AS-REQ ([^@]+)@(\S+?) from ipv[46]:\[?([0-9a-fA-F:.]+?)\]?:\d+ for krbtgt/")
CLOSE_OK = re.compile(r"Kerberos: No preauth found, returning PREAUTH-REQUIRED -- ([^@]+)@(\S+)")
CLOSE_BAD = re.compile(r"Kerberos: UNKNOWN -- ([^@]+)@(\S+): no such entry found in hdb")


def _mk_event(ts, ip, user, realm, code):
    result = 'KRB5' + code if code.startswith('KDC_') else 'KRB5KDC_' + code
    return '%s op=AS-REQ src_ip=%s user="%s@%s" result="%s"' % (ts, ip, user, realm, result)


def ship():
    root()
    last_ts, pending, sock, idle_buf = time.strftime('%Y-%m-%d %H:%M:%S'), {}, None, b''
    pend = __import__('collections').deque()
    off = SAMBA_LOG.stat().st_size
    while True:
        size = SAMBA_LOG.stat().st_size if SAMBA_LOG.exists() else 0
        if size < off:
            off, idle_buf = 0, b''
        if size > off:
            with SAMBA_LOG.open('rb') as f:
                f.seek(off)
                data = f.read(size - off)
            off += len(data)
            idle_buf += data
            *lines, idle_buf = idle_buf.split(b'\n')
            for raw in lines:
                line = raw.decode(errors='replace')
                m = HDR.match(line)
                if m:
                    last_ts = '%s-%s-%s %s' % m.group(1, 2, 3, 4)
                    continue
                s = ONELINE.search(line)
                if s:
                    code, ip, user, realm = s.groups()
                    pend.append(_mk_event(last_ts, ip, user, realm, code))
                    continue
                s = OPEN_REQ.search(line)
                if s:
                    user, realm, ip = s.groups()
                    pending[user + '@' + realm] = (ip, last_ts)
                    continue
                s = CLOSE_OK.search(line)
                if s:
                    key = s.group(1) + '@' + s.group(2)
                    ip, ts = pending.pop(key, (None, last_ts))
                    if ip:
                        pend.append(_mk_event(ts, ip, s.group(1), s.group(2), 'KDC_ERR_PREAUTH_REQUIRED'))
                    continue
                s = CLOSE_BAD.search(line)
                if s:
                    key = s.group(1) + '@' + s.group(2)
                    ip, ts = pending.pop(key, (None, last_ts))
                    if ip:
                        pend.append(_mk_event(ts, ip, s.group(1), s.group(2), 'KDC_ERR_C_PRINCIPAL_UNKNOWN'))
                    continue
        if pend:
            try:
                if sock is None:
                    sock = socket.create_connection((SPL, SHIP_PORT), timeout=5)
                while pend:
                    sock.sendall((pend[0] + '\n').encode())
                    print('shipped:', pend.popleft(), flush=True)
            except OSError:
                if sock:
                    sock.close()
                sock = None
                time.sleep(3)
        time.sleep(.2)


# ------------------------------------------------------------ attacker
def setup_attacker():
    root()
    hosts_add(DC, 'dc01.corp.internal dc01')
    s = socket.socket(); s.settimeout(5)
    require(s.connect_ex((DC, 88)) == 0, 'Khong ket noi duoc dc01:88 (Kerberos). Da chay ./start_dc01.sh chua?')
    s.close()
    print('Da them dc01.corp.internal vao /etc/hosts. Kerberos (88) tren dc01 da san sang.')
    print('ATTACKER_READY')


# -- probe AS-REQ khong preauth (dung impacket) va cong cu userenum theo dung dang kerbrute --
def _as_req_bytes(username, domain):
    from impacket.krb5 import constants
    from impacket.krb5.asn1 import AS_REQ, KERB_PA_PAC_REQUEST, seq_set, seq_set_iter
    from impacket.krb5.types import KerberosTime, Principal
    from pyasn1.codec.der import encoder
    from pyasn1.type.univ import noValue
    asReq = AS_REQ()
    clientName = Principal(username, type=constants.PrincipalNameType.NT_PRINCIPAL.value)
    pacRequest = KERB_PA_PAC_REQUEST(); pacRequest['include-pac'] = True
    asReq['pvno'] = 5
    asReq['msg-type'] = int(constants.ApplicationTagNumbers.AS_REQ.value)
    asReq['padata'] = noValue
    asReq['padata'][0] = noValue
    asReq['padata'][0]['padata-type'] = int(constants.PreAuthenticationDataTypes.PA_PAC_REQUEST.value)
    asReq['padata'][0]['padata-value'] = encoder.encode(pacRequest)
    reqBody = seq_set(asReq, 'req-body')
    opts = [constants.KDCOptions.forwardable.value, constants.KDCOptions.renewable.value,
            constants.KDCOptions.proxiable.value]
    reqBody['kdc-options'] = constants.encodeFlags(opts)
    seq_set(reqBody, 'sname', Principal('krbtgt/%s' % domain.upper(),
            type=constants.PrincipalNameType.NT_SRV_INST.value).components_to_asn1)
    seq_set(reqBody, 'cname', clientName.components_to_asn1)
    reqBody['realm'] = domain.upper()
    now = KerberosTime.to_asn1(datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=1))
    reqBody['till'] = now
    reqBody['rtime'] = now
    reqBody['nonce'] = random.randint(1, 2**31 - 1)
    seq_set_iter(reqBody, 'etype', (18, 17, 23))
    return encoder.encode(asReq)


def _probe_one(username, domain, dc):
    from impacket.krb5.asn1 import KRB_ERROR
    from impacket.krb5.kerberosv5 import sendReceive, KerberosError
    from impacket.krb5 import constants
    from pyasn1.codec.der import decoder
    try:
        r = sendReceive(_as_req_bytes(username, domain), domain, dc)
        err = decoder.decode(r, asn1Spec=KRB_ERROR())[0]
        return True, constants.ErrorCodes(int(err['error-code'])).name
    except KerberosError as e:
        return False, e.getErrorString()[0] if hasattr(e, 'getErrorString') else str(e)


def kerbrute_userenum(args):
    p = argparse.ArgumentParser(prog='kerbrute userenum')
    p.add_argument('-d', '--domain', required=True)
    p.add_argument('--dc', required=True)
    p.add_argument('wordlist')
    a = p.parse_args(args)
    users = [u.strip() for u in Path(a.wordlist).read_text().splitlines() if u.strip()]
    now = lambda: time.strftime('%Y/%m/%d %H:%M:%S')
    print('%s >\tUsing KDC(s):' % now())
    print('%s >\t\t%s:88' % (now(), a.dc))
    print()
    start, valid_n = time.time(), 0
    for u in users:
        ok, code = _probe_one(u, a.domain, a.dc)
        if ok:
            valid_n += 1
            print('%s >\t[+] VALID USERNAME:\t %s@%s' % (now(), u, a.domain))
    print('%s >\tDone! Tested %d usernames (%d valid) in %.3f seconds' % (
        now(), len(users), valid_n, time.time() - start))


def kerbrute(args):
    require(args and args[0] == 'userenum', 'Dung: kerbrute userenum -d <domain> --dc <dc> <wordlist>')
    kerbrute_userenum(args[1:])


# -------------------------------------------------------------- splunk
CONF = {
    'indexes.conf': '[ad_recon]\nhomePath = $SPLUNK_DB/ad_recon/db\ncoldPath = $SPLUNK_DB/ad_recon/colddb\n'
                    'thawedPath = $SPLUNK_DB/ad_recon/thaweddb\n',
    'inputs.conf': '[tcp://%d]\nindex = ad_recon\nsourcetype = samba:log\nconnection_host = none\n' % SHIP_PORT,
    'props.conf': '[samba:log]\nSHOULD_LINEMERGE = false\nKV_MODE = auto\nTIME_PREFIX = ^\n'
                  'TIME_FORMAT = %Y-%m-%d %H:%M:%S\nMAX_TIMESTAMP_LOOKAHEAD = 20\n',
    'user-seed.conf': '[user_info]\nUSERNAME = %s\nPASSWORD = %s\n' % (SPLUNK_USER, SPLUNK_PW),
}


def start_splunk():
    root()
    check_disk(1500)
    require(SPLUNK_HOME.exists(), 'Khong thay Splunk tai /opt/splunk (kiem tra buoc build image).')
    local = SPLUNK_HOME / 'etc/system/local'
    local.mkdir(parents=True, exist_ok=True)
    for name, text in CONF.items():
        if name == 'user-seed.conf' and (SPLUNK_HOME / 'etc/passwd').exists():
            continue
        (local / name).write_text(text)
    run(['chown', '-R', 'splunk:splunk', str(SPLUNK_HOME)])
    var = SPLUNK_HOME / 'var'
    var.mkdir(exist_ok=True)
    fstype = out(['stat', '-f', '-c', '%T', str(var)]).strip()
    print('Loai he tap tin cua /opt/splunk/var:', fstype)
    if fstype.startswith(('overlay', 'tmpfs')) and not listening(8089):
        print('CANH BAO: Splunk co the tu choi luu index tren ' + fstype + ' ("unusable filesystem").\n'
              'Image can khai bao VOLUME /opt/splunk/var (dung install.py moi + rebuild).')
    probe = subprocess.run(['sudo', '-u', 'splunk', 'sh', '-c',
                            'mkdir -p /opt/splunk/var/log && touch /opt/splunk/var/log/.w'],
                           text=True, capture_output=True)
    if probe.returncode:
        raise RuntimeError('User splunk khong ghi duoc /opt/splunk/var/log:\n' + probe.stderr)
    run(['sudo', '-u', 'splunk', 'sh', '-c', 'ulimit -f unlimited 2>/dev/null; exec ' + str(SPLUNK_HOME / 'bin/splunk') +
         ' start --accept-license --answer-yes --no-prompt'], stdout=subprocess.DEVNULL)
    wait_for(lambda: listening(8000) and listening(SHIP_PORT) and listening(8089), 180,
             'Splunk chua san sang (8000/8089/%d).' % SHIP_PORT)
    print('Splunk Web: http://%s:8000  (tai khoan %s / %s)' % (SPL, SPLUNK_USER, SPLUNK_PW))
    print('SPLUNK_READY')


def spl(query, host='127.0.0.1'):
    ctx = ssl._create_unverified_context()
    pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pw.add_password(None, 'https://%s:8089' % host, SPLUNK_USER, SPLUNK_PW)
    op = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx),
                                     urllib.request.HTTPBasicAuthHandler(pw))
    body = urllib.parse.urlencode({'search': 'search ' + query, 'output_mode': 'json',
                                   'earliest_time': '-24h'}).encode()
    rows = []
    with op.open('https://%s:8089/services/search/jobs/export' % host, body, timeout=60) as r:
        for line in r:
            if line.strip():
                res = json.loads(line).get('result')
                if res:
                    rows.append(res)
    return rows


def check_detection(args):
    # Chay tren container attacker, goi Splunk REST API qua mang (172.20.0.30:8089).
    # Cau SPL co dau " va dau | nen rat de bi terminal/wrapper cua Labtainer tach nham khi go
    # truc tiep tren dong lenh. De an toan, ho tro ca hai cach:
    #   ./check_detection.sh "<cau SPL mot dong, khong xuong dong>"
    #   ./check_detection.sh @duong_dan_file   (noi dung file la cau SPL, co the nhieu dong)
    require(len(args) == 1, 'Dung: check_detection.sh "<cau SPL>"  hoac  check_detection.sh @file.txt')
    query = Path(args[0][1:]).read_text().strip() if args[0].startswith('@') else args[0]
    require(query, 'Cau SPL rong.')
    rows, n = [], 0
    for _ in range(12):
        rows = spl(query, host=SPL)
        n = sum(int(r.get('count', 0)) for r in rows) if rows and 'count' in (rows[0] if rows else {}) else len(rows)
        if n > 0:
            break
        time.sleep(5)
    require(n > 0, 'Splunk chua tra ve su kien nao cho truy van nay. Chay du kerbrute roi thu lai.')
    for r in rows:
        print(r)
    print('DETECTION_CONFIRMED: %d events' % n)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('action')
    p.add_argument('rest', nargs=argparse.REMAINDER)
    a = p.parse_args()
    acts = {'start_dc01': start_dc01, 'ship': ship, 'setup_attacker': setup_attacker,
            'start_splunk': start_splunk}
    if a.action in acts:
        acts[a.action]()
    elif a.action == 'kerbrute':
        kerbrute(a.rest)
    elif a.action == 'check_detection':
        check_detection(a.rest)
    else:
        raise RuntimeError('Hanh dong khong hop le: ' + a.action)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print('FAILED: ' + str(exc), file=sys.stderr); sys.exit(1)
