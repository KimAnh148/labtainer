#!/usr/bin/env python3
"""Runtime cho bai lab recon-ad-ldap-anon (dc02 / attacker / splunk)."""
import argparse, glob, json, os, re, socket, ssl, subprocess, sys, time
import urllib.parse, urllib.request
from pathlib import Path

DC, ATK, SPL = '172.20.0.10', '172.20.0.20', '172.20.0.30'
REALM, DOMAIN, BASE = 'CORP.INTERNAL', 'CORP', 'DC=corp,DC=internal'
ADMINPW = 'Adm1n-Lab!2026'
SPLUNK_USER, SPLUNK_PW, SPLUNK_HOME = 'analyst', 'Splunk!Lab2026', Path('/opt/splunk')
SAMBA_LOG, SHIP_PORT = Path('/var/log/samba/log.samba'), 5514
SAM = '/var/lib/samba/private/sam.ldb'
DONE = Path('/var/lib/samba/.lab-provisioned')
DS_HEURISTICS_DN = 'CN=Directory Service,CN=Windows NT,CN=Services,CN=Configuration,' + BASE
ANON_SID = 'S-1-5-7'  # SID chuan cua "ANONYMOUS LOGON", khong doi theo domain


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, **kw)


def out(args, **kw):
    return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, **kw)


def root():
    require(os.geteuid() == 0, 'Hay chay bang script wrapper (can sudo).')


def listening(port):
    return bool(out(['ss', '-H', '-ltn', 'sport', '=', ':' + str(port)]).strip())


def wait_for(cond, seconds, msg):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return
        time.sleep(1)
    raise RuntimeError(msg)


def check_disk(need_mb):
    import shutil
    free = shutil.disk_usage('/').free // 2**20
    require(free >= need_mb, 'O dia con trong %d MB (can >= %d MB). Giai phong dia tren may Ubuntu '
            '(docker system prune) roi stoplab va chay lai.' % (free, need_mb))


def hosts_add(ip, names):
    p = Path('/etc/hosts')
    if names.split()[0] not in p.read_text():
        with p.open('a') as f:
            f.write('\n' + ip + ' ' + names + '\n')


def wipe_samba():
    for d in glob.glob('/var/lib/samba/private/*') + glob.glob('/var/lib/samba/sysvol/*'):
        run(['rm', '-rf', d])
    Path('/etc/samba/smb.conf').unlink(missing_ok=True)


def samba_running():
    return subprocess.run(['pgrep', '-x', 'samba'], stdout=subprocess.DEVNULL).returncode == 0


def ldb_env():
    mods = glob.glob('/usr/lib/*/samba/ldb') + glob.glob('/usr/lib/samba/ldb')
    return dict(os.environ, LDB_MODULES_PATH=mods[0] if mods else '')


def enable_anonymous_ldap():
    # Co tinh dua vao loi cau hinh: dsHeuristics=0000002 cho phep ANONYMOUS LOGON doc
    # domainDNS root (Domain SID/GUID) ma khong can bat ky thong tin dang nhap nao.
    # Da kiem thu thuc te: gia tri nay co hieu luc NGAY, khong can khoi dong lai Samba.
    ldif = ('dn: %s\nchangetype: modify\nreplace: dSHeuristics\ndSHeuristics: 0000002\n'
            % DS_HEURISTICS_DN)
    run(['ldbmodify', '-H', SAM], input=ldif, env=ldb_env(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def start_dc02():
    root()
    check_disk(300)
    require(glob.glob('/usr/lib/*/samba/vfs/acl_xattr.so'),
            'Thieu goi samba-vfs-modules trong image. Cai lai bang install.py moi va rebuild.')
    hosts_add(DC, 'dc02.corp.internal dc02')
    if not DONE.exists():
        print('Dang provision domain corp.internal (khoang 30-60 giay)...')
        cmd = ['samba-tool', 'domain', 'provision', '--realm=' + REALM, '--domain=' + DOMAIN,
               '--server-role=dc', '--dns-backend=SAMBA_INTERNAL', '--use-rfc2307',
               '--adminpass=' + ADMINPW]
        errors = []
        for extra in ([], ['--option=posix:eadb=/var/lib/samba/private/eadb.tdb']):
            wipe_samba()
            r = subprocess.run(cmd + extra, text=True, capture_output=True)
            if r.returncode == 0:
                break
            errors.append('--- lan thu %d (%s) ---\n%s' % (len(errors) + 1, ' '.join(extra) or 'mac dinh',
                          '\n'.join((r.stdout + r.stderr).strip().splitlines()[-15:])))
            print(errors[-1])
        else:
            wipe_samba()
            raise RuntimeError('Provision that bai (xem loi o tren). Gui nguyen van cho nguoi thiet ke.')
        enable_anonymous_ldap()
        conf = Path('/etc/samba/smb.conf')
        # Dinh dang dong log can thiet (kiem thu thuc te tren Samba 4.19.5):
        #   'ldapsrv_SearchRequest: LDAP Query: ... SearchRequest by SID from ipv4:IP:PORT
        #    filter: [...] basedn: [...] scope: [...] result: ...'
        # SID la 'S-1-5-7' (ANONYMOUS LOGON) khi bind an danh, hoac SID that cua user khi co
        # xac thuc. Dong nay ghi o muc log 5, KHONG can len muc 10 (khac voi dong rieng
        # 'BindSimple dn:' ma bai recon-ad-ldap-domain dung, dong do can muc 10).
        conf.write_text(conf.read_text().replace(
            '[global]', '[global]\n\tlog file = /var/log/samba/log.samba\n\tlog level = 5\n'
            '\tmax log size = 0', 1))
        DONE.write_text('ok')
    Path('/var/log/samba').mkdir(parents=True, exist_ok=True)
    if not samba_running():
        for name in ('smbd', 'nmbd', 'winbindd'):
            subprocess.run(['pkill', '-x', name])
        time.sleep(2)
        run(['samba', '-D'])
    try:
        wait_for(lambda: listening(389), 90, '')
    except RuntimeError:
        errs = subprocess.run("grep -a -i -E 'fail|error|cannot|bind' %s | tail -8" % SAMBA_LOG,
                              shell=True, text=True, capture_output=True).stdout
        procs = subprocess.run(['pgrep', '-a', 'smbd|nmbd|winbindd|samba'], text=True, capture_output=True).stdout
        raise RuntimeError('Samba chua lang nghe 389.\nTien trinh:\n%s\nLog gan nhat:\n%s' % (procs, errs))
    # Dam bao dsHeuristics da duoc ap dung (phong truong hop khoi dong lai tu trang thai cu).
    enable_anonymous_ldap()
    stop_shipper()
    SAMBA_LOG.touch()
    log = open('/var/log/lab-shipper.log', 'a')
    proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), 'ship'],
                            start_new_session=True, stdout=log, stderr=log)
    Path('/run/lab-shipper.pid').write_text(str(proc.pid))
    print('Domain corp.internal san sang (LDAP 389). Anonymous LDAP bind DA BI MO (dsHeuristics=0000002).')
    print('Shipper log -> Splunk %s:%d' % (SPL, SHIP_PORT))
    print('DC02_READY')


def stop_shipper():
    p = Path('/run/lab-shipper.pid')
    if p.exists():
        try:
            os.kill(int(p.read_text()), 15)
        except (OSError, ValueError):
            pass
        p.unlink(missing_ok=True)


# ---- shipper: doc log Samba, chuan hoa dong 'ldapsrv_SearchRequest: LDAP Query: ...',
# ---- day sang Splunk qua TCP ----
HDR = re.compile(r'^\[(\d{4})/(\d\d)/(\d\d) (\d\d:\d\d:\d\d)')
SEARCH = re.compile(r"ldapsrv_SearchRequest: LDAP Query:.*?SearchRequest by (\S+) from "
                    r"ipv[46]:\[?([0-9a-fA-F:.]+?)\]?:\d+ filter: \[(.*)\] basedn: \[(.*)\] "
                    r"scope: \[(\w+)\] result: (.*)$")


def normalize(ts, sid, ip, flt, base, scope, result):
    # Chuan hoa ve bind_dn="" khi la ANONYMOUS LOGON, dung voi cau SPL cua bai
    # (bind_dn="" OR "anonymous"); giu nguyen SID khi la user that (khong can cho bai nay).
    bind_dn = '' if sid == ANON_SID else sid
    q = lambda s: s.replace('"', "'")
    anon_tag = 'anonymous' if sid == ANON_SID else 'authenticated'
    return ('%s op=bind_search src_ip=%s bind_dn="%s" bind_type=%s basedn="%s" scope=%s '
            'filter="%s" result="%s"' % (ts, ip, bind_dn, anon_tag, q(base), scope, q(flt), q(result)))


def ship():
    root()
    from collections import deque
    pend, buf, last_ts = deque(), b'', time.strftime('%Y-%m-%d %H:%M:%S')
    off, sock = SAMBA_LOG.stat().st_size, None
    while True:
        size = SAMBA_LOG.stat().st_size if SAMBA_LOG.exists() else 0
        if size < off:
            off, buf = 0, b''
        if size > off:
            with SAMBA_LOG.open('rb') as f:
                f.seek(off)
                data = f.read(size - off)
            off += len(data)
            buf += data
            *lines, buf = buf.split(b'\n')
            for raw in lines:
                line = raw.decode(errors='replace')
                m = HDR.match(line)
                if m:
                    last_ts = '%s-%s-%s %s' % m.group(1, 2, 3, 4)
                    continue
                s = SEARCH.search(line)
                if s:
                    pend.append(normalize(last_ts, *s.groups()))
        if pend:
            try:
                if sock is None:
                    sock = socket.create_connection((SPL, SHIP_PORT), timeout=5)
                while pend:
                    sock.sendall((pend[0] + '\n').encode())
                    print('shipped:', pend.popleft(), flush=True)
            except OSError:
                if sock:
                    sock.close()
                sock = None
                time.sleep(3)
        time.sleep(.2)


# ------------------------------------------------------------ attacker
def setup_attacker():
    root()
    hosts_add(DC, 'dc02.corp.internal dc02')
    s = socket.socket(); s.settimeout(5)
    require(s.connect_ex((DC, 389)) == 0, 'Khong ket noi duoc dc02:389 (LDAP). Da chay ./start_dc02.sh chua?')
    s.close()
    print('Da them dc02.corp.internal vao /etc/hosts. LDAP (389) tren dc02 da san sang.')
    print('Khong co bat ky thong tin xac thuc domain nao duoc cap cho may nay (dung y cua bai).')
    print('ATTACKER_READY')


# -------------------------------------------------------------- splunk
CONF = {
    'indexes.conf': '[ad_recon]\nhomePath = $SPLUNK_DB/ad_recon/db\ncoldPath = $SPLUNK_DB/ad_recon/colddb\n'
                    'thawedPath = $SPLUNK_DB/ad_recon/thaweddb\n',
    'inputs.conf': '[tcp://%d]\nindex = ad_recon\nsourcetype = samba:log\nconnection_host = none\n' % SHIP_PORT,
    'props.conf': '[samba:log]\nSHOULD_LINEMERGE = false\nKV_MODE = auto\nTIME_PREFIX = ^\n'
                  'TIME_FORMAT = %Y-%m-%d %H:%M:%S\nMAX_TIMESTAMP_LOOKAHEAD = 20\n',
    'user-seed.conf': '[user_info]\nUSERNAME = %s\nPASSWORD = %s\n' % (SPLUNK_USER, SPLUNK_PW),
}


def start_splunk():
    root()
    check_disk(1500)
    require(SPLUNK_HOME.exists(), 'Khong thay Splunk tai /opt/splunk (kiem tra buoc build image).')
    local = SPLUNK_HOME / 'etc/system/local'
    local.mkdir(parents=True, exist_ok=True)
    for name, text in CONF.items():
        if name == 'user-seed.conf' and (SPLUNK_HOME / 'etc/passwd').exists():
            continue
        (local / name).write_text(text)
    run(['chown', '-R', 'splunk:splunk', str(SPLUNK_HOME)])
    var = SPLUNK_HOME / 'var'
    var.mkdir(exist_ok=True)
    fstype = out(['stat', '-f', '-c', '%T', str(var)]).strip()
    print('Loai he tap tin cua /opt/splunk/var:', fstype)
    if fstype.startswith(('overlay', 'tmpfs')) and not listening(8089):
        print('CANH BAO: Splunk co the tu choi luu index tren ' + fstype + ' ("unusable filesystem").\n'
              'Image can khai bao VOLUME /opt/splunk/var (dung install.py moi + rebuild).')
    probe = subprocess.run(['sudo', '-u', 'splunk', 'sh', '-c',
                            'mkdir -p /opt/splunk/var/log && touch /opt/splunk/var/log/.w'],
                           text=True, capture_output=True)
    if probe.returncode:
        raise RuntimeError('User splunk khong ghi duoc /opt/splunk/var/log:\n' + probe.stderr)
    run(['sudo', '-u', 'splunk', 'sh', '-c', 'ulimit -f unlimited 2>/dev/null; exec ' + str(SPLUNK_HOME / 'bin/splunk') +
         ' start --accept-license --answer-yes --no-prompt'], stdout=subprocess.DEVNULL)
    wait_for(lambda: listening(8000) and listening(SHIP_PORT) and listening(8089), 180,
             'Splunk chua san sang (8000/8089/%d).' % SHIP_PORT)
    print('Splunk Web: http://%s:8000  (tai khoan %s / %s)' % (SPL, SPLUNK_USER, SPLUNK_PW))
    print('SPLUNK_READY')


def spl(query, host='127.0.0.1'):
    ctx = ssl._create_unverified_context()
    pw = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    pw.add_password(None, 'https://%s:8089' % host, SPLUNK_USER, SPLUNK_PW)
    op = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), urllib.request.HTTPBasicAuthHandler(pw))
    body = urllib.parse.urlencode({'search': 'search ' + query, 'output_mode': 'json',
                                   'earliest_time': '-24h'}).encode()
    rows = []
    with op.open('https://%s:8089/services/search/jobs/export' % host, body, timeout=60) as r:
        for line in r:
            if line.strip():
                res = json.loads(line).get('result')
                if res:
                    rows.append(res)
    return rows


def check_detection(args):
    # Chay tren container attacker, goi Splunk REST API qua mang (172.20.0.30:8089).
    # Ho tro ca hai cach goi (xem HUONG_DAN.txt):
    #   ./check_detection.sh "<cau SPL mot dong>"
    #   ./check_detection.sh @duong_dan_file
    require(len(args) == 1, 'Dung: check_detection.sh "<cau SPL>"  hoac  check_detection.sh @file.txt')
    query = Path(args[0][1:]).read_text().strip() if args[0].startswith('@') else args[0]
    require(query, 'Cau SPL rong.')
    rows, n = [], 0
    for _ in range(12):
        rows = spl(query, host=SPL)
        n = sum(int(r.get('count', 0)) for r in rows) if rows and 'count' in (rows[0] if rows else {}) else len(rows)
        if n > 0:
            break
        time.sleep(5)
    require(n > 0, 'Splunk chua tra ve su kien nao cho truy van nay. Chay du Buoc 1-2 roi thu lai.')
    for r in rows:
        print(r)
    print('DETECTION_CONFIRMED: %d events' % n)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('action')
    p.add_argument('rest', nargs=argparse.REMAINDER)
    a = p.parse_args()
    acts = {'start_dc02': start_dc02, 'ship': ship, 'setup_attacker': setup_attacker,
            'start_splunk': start_splunk}
    if a.action in acts:
        acts[a.action]()
    elif a.action == 'check_detection':
        check_detection(a.rest)
    else:
        raise RuntimeError('Hanh dong khong hop le: ' + a.action)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print('FAILED: ' + str(exc), file=sys.stderr); sys.exit(1)
